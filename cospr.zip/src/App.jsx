import React, { useState, useRef, useEffect } from "react";

// ---------- Icons ----------
const Icon = {
  plus: (p) => (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" {...p}><path d="M12 5v14M5 12h14" strokeLinecap="round" /></svg>),
  search: (p) => (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" {...p}><circle cx="11" cy="11" r="7" /><path d="M21 21l-4.35-4.35" strokeLinecap="round" /></svg>),
  compass: (p) => (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" {...p}><circle cx="12" cy="12" r="10" /><path d="M16.24 7.76l-2.12 6.36-6.36 2.12 2.12-6.36 6.36-2.12z" strokeLinejoin="round" /></svg>),
  grid: (p) => (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" {...p}><rect x="3" y="3" width="7" height="7" rx="1.5" /><rect x="14" y="3" width="7" height="7" rx="1.5" /><rect x="3" y="14" width="7" height="7" rx="1.5" /><rect x="14" y="14" width="7" height="7" rx="1.5" /></svg>),
  history: (p) => (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" {...p}><path d="M3 12a9 9 0 1 0 3-6.7" strokeLinecap="round" strokeLinejoin="round" /><path d="M3 4v5h5" strokeLinecap="round" strokeLinejoin="round" /><path d="M12 7v5l3 3" strokeLinecap="round" strokeLinejoin="round" /></svg>),
  settings: (p) => (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" {...p}><circle cx="12" cy="12" r="3" /><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.6a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z" /></svg>),
  paperclip: (p) => (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" {...p}><path d="M21.44 11.05l-9.19 9.19a6 6 0 0 1-8.49-8.49l9.19-9.19a4 4 0 0 1 5.66 5.66l-9.2 9.19a2 2 0 0 1-2.83-2.83l8.49-8.48" strokeLinecap="round" strokeLinejoin="round" /></svg>),
  image: (p) => (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" {...p}><rect x="3" y="3" width="18" height="18" rx="2" /><circle cx="8.5" cy="8.5" r="1.5" /><path d="M21 15l-5-5L5 21" strokeLinecap="round" strokeLinejoin="round" /></svg>),
  camera: (p) => (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" {...p}><path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z" strokeLinecap="round" strokeLinejoin="round" /><circle cx="12" cy="13" r="4" /></svg>),
  send: (p) => (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" {...p}><path d="M22 2L11 13M22 2l-7 20-4-9-9-4z" strokeLinecap="round" strokeLinejoin="round" /></svg>),
  mic: (p) => (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" {...p}><path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z" /><path d="M19 10v2a7 7 0 0 1-14 0v-2M12 19v4M8 23h8" strokeLinecap="round" /></svg>),
  sparkle: (p) => (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" {...p}><path d="M12 3v4M12 17v4M3 12h4M17 12h4M5.6 5.6l2.8 2.8M15.6 15.6l2.8 2.8M18.4 5.6l-2.8 2.8M8.4 15.6l-2.8 2.8" strokeLinecap="round" /></svg>),
  layers: (p) => (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" {...p}><path d="M12 2l9 5-9 5-9-5 9-5z" strokeLinejoin="round" /><path d="M3 12l9 5 9-5M3 17l9 5 9-5" strokeLinecap="round" strokeLinejoin="round" /></svg>),
  map: (p) => (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" {...p}><path d="M9 20l-6-3V4l6 3 6-3 6 3v13l-6-3-6 3z" strokeLinejoin="round" /><path d="M9 7v13M15 4v13" /></svg>),
  target: (p) => (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" {...p}><circle cx="12" cy="12" r="9" /><circle cx="12" cy="12" r="5" /><circle cx="12" cy="12" r="1" /></svg>),
  close: (p) => (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" {...p}><path d="M18 6L6 18M6 6l12 12" strokeLinecap="round" /></svg>),
  chevron: (p) => (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" {...p}><path d="M6 9l6 6 6-6" strokeLinecap="round" /></svg>),
  more: (p) => (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" {...p}><circle cx="5" cy="12" r="1.5" /><circle cx="12" cy="12" r="1.5" /><circle cx="19" cy="12" r="1.5" /></svg>),
};

const MODE_CONFIG = {
  ask: { label: "Ask", icon: Icon.sparkle, color: "#8B7CFF", sub: [
    { key: "ask", label: "Ask", desc: "Quick answer, fast model" },
    { key: "ask_thinking", label: "Ask + Thinking", desc: "Reasons before answering" },
  ]},
  research: { label: "Research", icon: Icon.search, color: "#4FD1C5", sub: [
    { key: "research", label: "Research", desc: "Multi-source search & summary" },
    { key: "deep_research", label: "Deep Research + Thinking", desc: "Patterns, contradictions, insight" },
  ]},
  plan: { label: "Plan", icon: Icon.map, color: "#F0B457", sub: [
    { key: "plan", label: "Plan", desc: "Straightforward action plan" },
    { key: "deep_plan", label: "Deep Plan + Thinking", desc: "Full strategy with tradeoffs" },
  ]},
};

const FEATURE_CARDS = [
  { icon: Icon.layers, iconBg: "linear-gradient(135deg,#F0B457,#D98A2B)", title: "Validate a startup idea before you build it — competitors, gaps, risk.", tag: "Startup Validation" },
  { icon: Icon.target, iconBg: "linear-gradient(135deg,#4FD1C5,#2BA89E)", title: "Compare tech stacks with real GitHub activity and dev sentiment.", tag: "Technology Research" },
  { icon: Icon.layers, iconBg: "linear-gradient(135deg,#8B7CFF,#5B4FD9)", title: "Analyze a competitor's pricing, complaints, and moat.", tag: "Competitor Research" },
];

const HISTORY = [
  { id: 1, title: "AI note-taking startup validation", time: "2h ago", mode: "research" },
  { id: 2, title: "Next.js vs Svelte for SaaS", time: "Yesterday", mode: "ask" },
  { id: 3, title: "Cursor pricing and moat analysis", time: "Yesterday", mode: "plan" },
  { id: 4, title: "Developer sentiment on Bun", time: "3 days ago", mode: "research" },
];

const STAGES = ["Understanding intent", "Selecting sources", "Collecting data", "Finding patterns", "Generating insight"];

const SAMPLE_REPORT = `## Summary
AI note-taking is a crowded space, but most incumbents optimize for consumers, not founders who need research-grade memory.

## Key Findings
- Notion, Obsidian, and Mem dominate mindshare but skew toward general productivity.
- Reddit complaints cluster around search quality and AI accuracy, not feature count.

## Patterns
- Every major complaint across sources is retrieval quality, not UI polish.

## Opportunities
- A founder-only memory layer tied to research and decisions, not generic notes.

## Recommendation
Build a narrow wedge: memory linked to research sessions, not a general notes app.`;

function ModeDot({ mode }) {
  return <span className="mode-dot" style={{ background: MODE_CONFIG[mode]?.color || "#8B7CFF" }} />;
}

function Report({ text }) {
  const lines = text.split("\n");
  return (
    <div className="report">
      {lines.map((line, i) => {
        if (line.startsWith("## ")) return <h2 key={i}>{line.replace("## ", "")}</h2>;
        if (line.trim().startsWith("- ")) return <li key={i}>{line.trim().replace(/^- /, "")}</li>;
        if (line.trim() === "") return <div key={i} className="spacer" />;
        return <p key={i}>{line}</p>;
      })}
    </div>
  );
}

// ---------- Slim icon sidebar (exact reference style) ----------
function IconSidebar({ activePanel, setActivePanel, onNewResearch }) {
  return (
    <aside className="icon-sidebar">
      <button className="icon-sidebar-plus" onClick={onNewResearch} title="New research">
        <Icon.plus className="icon-16" />
      </button>

      <div className="icon-sidebar-group">
        <button
          className={`icon-sidebar-btn ${activePanel === "search" ? "icon-sidebar-btn-active" : ""}`}
          onClick={() => setActivePanel(activePanel === "search" ? null : "search")}
          title="Search"
        >
          <Icon.search className="icon-16" />
        </button>
        <button
          className={`icon-sidebar-btn ${activePanel === "explore" ? "icon-sidebar-btn-active" : ""}`}
          onClick={() => setActivePanel(activePanel === "explore" ? null : "explore")}
          title="Explore modes"
        >
          <Icon.compass className="icon-16" />
        </button>
        <button
          className={`icon-sidebar-btn ${activePanel === "apps" ? "icon-sidebar-btn-active" : ""}`}
          onClick={() => setActivePanel(activePanel === "apps" ? null : "apps")}
          title="Micro-tools"
        >
          <Icon.grid className="icon-16" />
        </button>
        <button
          className={`icon-sidebar-btn ${activePanel === "history" ? "icon-sidebar-btn-active" : ""}`}
          onClick={() => setActivePanel(activePanel === "history" ? null : "history")}
          title="History"
        >
          <Icon.history className="icon-16" />
        </button>
      </div>

      <div className="icon-sidebar-spacer" />

      <button
        className={`icon-sidebar-btn ${activePanel === "settings" ? "icon-sidebar-btn-active" : ""}`}
        onClick={() => setActivePanel(activePanel === "settings" ? null : "settings")}
        title="Settings"
      >
        <Icon.settings className="icon-15" />
      </button>
      <button className="icon-sidebar-avatar" title="Profile" onClick={() => setActivePanel("profile")}>L</button>
    </aside>
  );
}

// ---------- Expandable side panel (History / Settings / Profile / Explore) ----------
function SidePanel({ type, onClose }) {
  if (!type) return null;

  return (
    <>
      <div className="panel-overlay" onClick={onClose} />
      <div className="side-panel">
        <div className="side-panel-header">
          <h2>
            {type === "history" && "Research history"}
            {type === "search" && "Search"}
            {type === "explore" && "Research modes"}
            {type === "apps" && "Micro-tools"}
            {type === "settings" && "Settings"}
            {type === "profile" && "Profile"}
          </h2>
          <button className="icon-btn-sm" onClick={onClose}><Icon.close className="icon-16" /></button>
        </div>

        <div className="side-panel-body">
          {type === "history" && (
            <div className="history-list">
              {HISTORY.map((h) => (
                <div key={h.id} className="history-item">
                  <ModeDot mode={h.mode} />
                  <div className="history-item-text">
                    <div className="history-item-title">{h.title}</div>
                    <div className="history-item-time">{h.time}</div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {type === "search" && (
            <div className="panel-search">
              <input className="panel-search-input" placeholder="Search past research..." autoFocus />
            </div>
          )}

          {type === "explore" && (
            <div className="explore-list">
              {Object.entries(MODE_CONFIG).map(([key, cfg]) => (
                <div key={key} className="explore-group">
                  <div className="explore-group-title" style={{ color: cfg.color }}>{cfg.label}</div>
                  {cfg.sub.map((s) => (
                    <div key={s.key} className="explore-item">
                      <div className="explore-item-title">{s.label}</div>
                      <div className="explore-item-desc">{s.desc}</div>
                    </div>
                  ))}
                </div>
              ))}
            </div>
          )}

          {type === "apps" && (
            <div className="apps-grid">
              {["Competitor Tracker", "Pricing Benchmark", "GitHub Activity Check", "Reddit Sentiment", "Market Sizing", "Idea Validator"].map((a) => (
                <div key={a} className="app-tile">{a}</div>
              ))}
            </div>
          )}

          {type === "settings" && (
            <>
              <div className="panel-section">
                <div className="panel-section-title">Appearance</div>
                <div className="settings-row">
                  <div>
                    <div className="settings-row-label">Theme</div>
                    <div className="settings-row-desc">Interface color mode</div>
                  </div>
                  <div className="segmented">
                    <button className="seg-active">Dark</button>
                    <button>Light</button>
                  </div>
                </div>
              </div>
              <div className="panel-section">
                <div className="panel-section-title">Research defaults</div>
                <div className="settings-row">
                  <div>
                    <div className="settings-row-label">Default mode</div>
                    <div className="settings-row-desc">Used for new research</div>
                  </div>
                  <select className="select" defaultValue="research">
                    <option value="ask">Ask</option>
                    <option value="research">Research</option>
                    <option value="plan">Plan</option>
                  </select>
                </div>
                <div className="settings-row">
                  <div>
                    <div className="settings-row-label">Sources</div>
                    <div className="settings-row-desc">Included by default</div>
                  </div>
                  <div className="chips">
                    <span className="chip chip-on">Web</span>
                    <span className="chip chip-on">Reddit</span>
                    <span className="chip chip-on">GitHub</span>
                    <span className="chip">News</span>
                  </div>
                </div>
              </div>
              <div className="panel-section">
                <div className="panel-section-title">Notifications</div>
                <div className="settings-row">
                  <div>
                    <div className="settings-row-label">Email updates</div>
                    <div className="settings-row-desc">Usage summaries, product news</div>
                  </div>
                  <label className="switch">
                    <input type="checkbox" defaultChecked />
                    <span className="switch-slider" />
                  </label>
                </div>
              </div>
            </>
          )}

          {type === "profile" && (
            <>
              <div className="profile-hero">
                <div className="avatar-lg">L</div>
                <div>
                  <div className="profile-hero-name">Logosi</div>
                  <div className="profile-hero-sub">Builder · Logrith</div>
                </div>
              </div>
              <div className="panel-section">
                <div className="panel-section-title">Account</div>
                <div className="settings-row">
                  <div>
                    <div className="settings-row-label">Email</div>
                    <div className="settings-row-desc">logosi@logrith.in</div>
                  </div>
                  <button className="btn-secondary">Change</button>
                </div>
              </div>
              <div className="panel-section">
                <div className="panel-section-title">Plan & usage</div>
                <div className="plan-card">
                  <div className="plan-card-top">
                    <span className="plan-name">Free Plan</span>
                    <button className="btn-primary-sm">Upgrade</button>
                  </div>
                  <div className="usage-row"><span>Research</span><div className="usage-bar"><div className="usage-fill" style={{ width: "60%" }} /></div><span className="usage-count">6/10</span></div>
                  <div className="usage-row"><span>Deep Research</span><div className="usage-bar"><div className="usage-fill" style={{ width: "0%" }} /></div><span className="usage-count">0/2</span></div>
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </>
  );
}

// ---------- Attach popup ----------
function AttachMenu({ open, onClose }) {
  const ref = useRef(null);
  useEffect(() => {
    function onClick(e) { if (ref.current && !ref.current.contains(e.target)) onClose(); }
    if (open) document.addEventListener("mousedown", onClick);
    return () => document.removeEventListener("mousedown", onClick);
  }, [open, onClose]);
  if (!open) return null;
  return (
    <div className="attach-popup" ref={ref}>
      <div className="attach-item"><Icon.paperclip className="icon-15" /> Attach file</div>
      <div className="attach-item"><Icon.image className="icon-15" /> Attach image</div>
      <div className="attach-item"><Icon.camera className="icon-15" /> Camera</div>
    </div>
  );
}

// ---------- Mode pill popup (for Deep Research etc pills) ----------
function ModeExpandPopup({ modeKey, open, onClose, onSelect }) {
  const ref = useRef(null);
  useEffect(() => {
    function onClick(e) { if (ref.current && !ref.current.contains(e.target)) onClose(); }
    if (open) document.addEventListener("mousedown", onClick);
    return () => document.removeEventListener("mousedown", onClick);
  }, [open, onClose]);
  if (!open) return null;
  const cfg = MODE_CONFIG[modeKey];
  return (
    <div className="mode-expand-popup" ref={ref}>
      {cfg.sub.map((s) => (
        <div key={s.key} className="mode-pill-item" onClick={() => { onSelect(modeKey, s.key); onClose(); }}>
          <div className="mode-pill-item-title">{s.label}</div>
          <div className="mode-pill-item-desc">{s.desc}</div>
        </div>
      ))}
    </div>
  );
}

export default function App() {
  const [activePanel, setActivePanel] = useState(null);
  const [query, setQuery] = useState("");
  const [mainMode, setMainMode] = useState("research");
  const [subMode, setSubMode] = useState("research");
  const [attachOpen, setAttachOpen] = useState(false);
  const [openPillMode, setOpenPillMode] = useState(null);
  const [loading, setLoading] = useState(false);
  const [stageIdx, setStageIdx] = useState(0);
  const [result, setResult] = useState(null);
  const timerRef = useRef(null);

  function handleModeSelect(main, sub) { setMainMode(main); setSubMode(sub); }

  function handleSend() {
    if (!query.trim() || loading) return;
    setResult(null);
    setLoading(true);
    setStageIdx(0);
    let i = 0;
    timerRef.current = setInterval(() => {
      i += 1;
      setStageIdx(i);
      if (i >= STAGES.length - 1) {
        clearInterval(timerRef.current);
        setTimeout(() => { setLoading(false); setResult({ report: SAMPLE_REPORT }); }, 500);
      }
    }, 400);
  }

  useEffect(() => () => clearInterval(timerRef.current), []);
  const hasContent = loading || result;

  return (
    <div className="app">
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap');
        * { box-sizing: border-box; margin: 0; padding: 0; }
        html, body, #root { height: 100%; }
        .app {
          display: flex; height: 100vh; width: 100%;
          background:
            radial-gradient(ellipse 70% 50% at 20% 0%, rgba(139,124,255,0.10), transparent),
            radial-gradient(ellipse 60% 40% at 90% 10%, rgba(79,209,197,0.06), transparent),
            #08080B;
          color: #E4E4E9; font-family: 'Inter', -apple-system, sans-serif;
          overflow: hidden; position: relative; padding: 14px; gap: 14px;
        }

        /* ---------- Slim icon sidebar ---------- */
        .icon-sidebar {
          width: 56px; flex-shrink: 0; background: #131318;
          border: 1px solid rgba(255,255,255,0.07); border-radius: 20px;
          display: flex; flex-direction: column; align-items: center;
          padding: 14px 0; gap: 10px;
        }
        .icon-sidebar-plus {
          width: 34px; height: 34px; border-radius: 50%; border: none;
          background: #EAEAEF; color: #0A0A0D; display: flex; align-items: center;
          justify-content: center; cursor: pointer; transition: transform 0.12s, filter 0.15s;
          margin-bottom: 4px;
        }
        .icon-sidebar-plus:hover { filter: brightness(0.92); }
        .icon-sidebar-plus:active { transform: scale(0.94); }

        .icon-sidebar-group { display: flex; flex-direction: column; gap: 6px; }
        .icon-sidebar-btn {
          width: 34px; height: 34px; border-radius: 50%; border: none;
          background: transparent; color: #8A8A96; display: flex;
          align-items: center; justify-content: center; cursor: pointer;
          transition: background 0.15s, color 0.15s;
        }
        .icon-sidebar-btn:hover { background: rgba(255,255,255,0.06); color: #E4E4E9; }
        .icon-sidebar-btn-active { background: rgba(139,124,255,0.16); color: #C4B8FF; }

        .icon-sidebar-spacer { flex: 1; }
        .icon-sidebar-avatar {
          width: 30px; height: 30px; border-radius: 50%; border: none;
          background: linear-gradient(135deg,#8B7CFF,#4C3FD9); color: white;
          font-size: 12px; font-weight: 600; cursor: pointer;
          display: flex; align-items: center; justify-content: center;
        }

        /* ---------- Main content ---------- */
        .main-view {
          flex: 1; display: flex; flex-direction: column; overflow: hidden;
          border: 1px solid rgba(255,255,255,0.06); border-radius: 20px;
          background: #0C0C10; position: relative; min-width: 0;
        }

        .center-wrap { flex: 1; overflow-y: auto; display: flex; flex-direction: column; align-items: center; justify-content: center; padding: 24px; }

        .greeting { text-align: center; margin-bottom: 32px; }
        .greeting h1 { font-size: 28px; font-weight: 600; letter-spacing: -0.02em; line-height: 1.25; }
        .greeting .accent { color: #A79CFF; }

        .feature-cards { display: flex; gap: 12px; max-width: 780px; width: 100%; }
        .feature-card {
          flex: 1; background: #131318; border: 1px solid rgba(255,255,255,0.07);
          border-radius: 16px; padding: 18px; cursor: pointer;
          transition: border-color 0.15s, transform 0.15s;
        }
        .feature-card:hover { border-color: rgba(139,124,255,0.3); transform: translateY(-2px); }
        .feature-card-icon {
          width: 34px; height: 34px; border-radius: 10px; display: flex;
          align-items: center; justify-content: center; color: white; margin-bottom: 14px;
        }
        .feature-card-title { font-size: 13px; line-height: 1.5; color: #D4D4DE; margin-bottom: 12px; min-height: 58px; }
        .feature-card-tag { font-size: 10.5px; color: #63636D; font-family: 'JetBrains Mono', monospace; }

        .results { flex: 1; overflow-y: auto; padding: 20px 24px 8px; max-width: 760px; margin: 0 auto; width: 100%; }

        .trace { background: #131318; border: 1px solid rgba(255,255,255,0.07); border-radius: 14px; padding: 16px 18px; margin-bottom: 16px; }
        .trace-row { display: flex; align-items: center; gap: 10px; padding: 6px 0; font-size: 13px; color: #45454F; transition: color 0.3s; }
        .trace-row.trace-active { color: #E4E4E9; }
        .trace-row.trace-done { color: #A79CFF; }
        .trace-marker { width: 15px; height: 15px; border-radius: 50%; border: 1.5px solid #2A2A32; display: flex; align-items: center; justify-content: center; font-size: 9px; flex-shrink: 0; }
        .trace-done .trace-marker { border-color: #8B7CFF; background: rgba(139,124,255,0.15); }
        .trace-active .trace-marker { border-color: #8B7CFF; background: #8B7CFF; animation: pulse 1s infinite; }
        @keyframes pulse { 0%, 100% { box-shadow: 0 0 0 0 rgba(139,124,255,0.4); } 50% { box-shadow: 0 0 0 5px rgba(139,124,255,0); } }

        .card { background: #131318; border: 1px solid rgba(255,255,255,0.07); border-radius: 16px; padding: 22px 24px; }
        .tags { display: flex; gap: 6px; flex-wrap: wrap; margin-bottom: 16px; }
        .tag { font-family: 'JetBrains Mono', monospace; font-size: 10.5px; padding: 4px 9px; border-radius: 6px; display: inline-flex; align-items: center; gap: 5px; }
        .tag-mode { background: rgba(139,124,255,0.16); color: #C4B8FF; }
        .tag-source { background: rgba(255,255,255,0.05); color: #747482; }
        .mode-dot { width: 6px; height: 6px; border-radius: 50%; flex-shrink: 0; }

        .report h2 { font-size: 14px; font-weight: 600; color: #C4B8FF; margin: 16px 0 7px; }
        .report h2:first-child { margin-top: 0; }
        .report p, .report li { font-size: 13.5px; line-height: 1.65; color: #A8A8B4; margin-bottom: 4px; }
        .report li { margin-left: 18px; }
        .spacer { height: 2px; }

        /* ---------- Composer (bottom card, matches reference) ---------- */
        .composer-outer { max-width: 760px; margin: 0 auto 18px; width: 100%; padding: 0 18px; }
        .composer-card {
          background: #131318; border: 1px solid rgba(255,255,255,0.08);
          border-radius: 18px; padding: 10px 14px;
        }
        .composer-topline { display: flex; align-items: center; justify-content: space-between; padding: 2px 4px 8px; font-size: 11px; color: #55555F; }
        .composer-topline .upgrade { color: #A79CFF; display: flex; align-items: center; gap: 5px; }

        .composer-inputrow { display: flex; align-items: center; gap: 8px; padding: 4px 2px; }
        .composer-left { position: relative; }
        .attach-btn {
          width: 30px; height: 30px; border-radius: 50%; background: rgba(255,255,255,0.05);
          border: none; color: #8A8A96; display: flex; align-items: center; justify-content: center;
          cursor: pointer; flex-shrink: 0; transition: background 0.15s, color 0.15s;
        }
        .attach-btn:hover { background: rgba(255,255,255,0.09); color: #E4E4E9; }
        .attach-popup {
          position: absolute; bottom: calc(100% + 8px); left: 0;
          background: #1A1A21; border: 1px solid rgba(255,255,255,0.1);
          border-radius: 10px; padding: 5px; width: 170px;
          box-shadow: 0 12px 32px -8px rgba(0,0,0,0.6); z-index: 20;
        }
        .attach-item { display: flex; align-items: center; gap: 9px; padding: 8px 9px; border-radius: 7px; cursor: pointer; font-size: 12.5px; color: #C4C4CE; transition: background 0.15s; }
        .attach-item:hover { background: rgba(255,255,255,0.06); }

        .composer-inputrow input {
          flex: 1; background: transparent; border: none; outline: none;
          color: #E4E4E9; font-size: 14px; font-family: inherit; min-width: 0;
        }
        .composer-inputrow input::placeholder { color: #55555F; }

        .composer-right { display: flex; align-items: center; gap: 6px; }
        .round-btn {
          width: 30px; height: 30px; border-radius: 50%; border: none;
          background: rgba(255,255,255,0.05); color: #8A8A96;
          display: flex; align-items: center; justify-content: center; cursor: pointer;
          transition: background 0.15s, color 0.15s;
        }
        .round-btn:hover { background: rgba(255,255,255,0.09); color: #E4E4E9; }
        .round-btn-send { background: #EAEAEF; color: #0A0A0D; }
        .round-btn-send:hover { background: #EAEAEF; filter: brightness(0.94); }
        .round-btn-send:disabled { opacity: 0.35; cursor: default; }

        .composer-pills { display: flex; gap: 7px; flex-wrap: wrap; padding: 10px 2px 2px; position: relative; }
        .pill-btn {
          display: flex; align-items: center; gap: 6px;
          background: rgba(255,255,255,0.04); border: 1px solid rgba(255,255,255,0.07);
          color: #B8B8C2; padding: 7px 12px; border-radius: 20px;
          font-size: 12px; cursor: pointer; transition: background 0.15s, border-color 0.15s;
          white-space: nowrap;
        }
        .pill-btn:hover { background: rgba(255,255,255,0.08); }
        .pill-btn-active { background: rgba(139,124,255,0.14); border-color: rgba(139,124,255,0.35); color: #C4B8FF; }
        .pill-btn-icon { width: 13px; height: 13px; }
        .pill-more {
          width: 30px; height: 30px; border-radius: 50%; background: rgba(255,255,255,0.04);
          border: 1px solid rgba(255,255,255,0.07); color: #8A8A96;
          display: flex; align-items: center; justify-content: center; cursor: pointer;
        }

        .mode-pill-item { padding: 8px 10px; border-radius: 8px; cursor: pointer; transition: background 0.15s; }
        .mode-pill-item:hover { background: rgba(255,255,255,0.06); }
        .mode-pill-item-title { font-size: 12.5px; color: #E4E4E9; font-weight: 500; }
        .mode-pill-item-desc { font-size: 10.5px; color: #63636D; margin-top: 1px; }
        .mode-expand-popup {
          position: absolute; bottom: calc(100% + 8px); left: 0;
          background: #1A1A21; border: 1px solid rgba(255,255,255,0.1);
          border-radius: 12px; padding: 6px; width: 230px;
          box-shadow: 0 12px 32px -8px rgba(0,0,0,0.6); z-index: 20;
        }

        /* ---------- Expandable side panel ---------- */
        .panel-overlay { position: fixed; inset: 0; background: rgba(0,0,0,0.4); z-index: 60; }
        .side-panel {
          position: fixed; top: 14px; left: 84px; bottom: 14px; width: 340px; max-width: calc(100vw - 100px);
          background: #0F0F13; border: 1px solid rgba(255,255,255,0.08); border-radius: 18px;
          z-index: 70; display: flex; flex-direction: column;
          box-shadow: 0 24px 60px -20px rgba(0,0,0,0.7);
        }
        .side-panel-header { display: flex; align-items: center; justify-content: space-between; padding: 16px 18px; border-bottom: 1px solid rgba(255,255,255,0.06); }
        .side-panel-header h2 { font-size: 15px; font-weight: 600; }
        .side-panel-body { flex: 1; overflow-y: auto; padding: 14px 16px; }

        .icon-btn-sm { background: transparent; border: none; color: #7A7A88; cursor: pointer; padding: 5px; border-radius: 6px; display: flex; transition: background 0.15s, color 0.15s; }
        .icon-btn-sm:hover { background: rgba(255,255,255,0.06); color: #E4E4E9; }

        .history-list { display: flex; flex-direction: column; gap: 2px; }
        .history-item { display: flex; align-items: flex-start; gap: 9px; padding: 9px 8px; border-radius: 9px; cursor: pointer; transition: background 0.15s; }
        .history-item:hover { background: rgba(255,255,255,0.05); }
        .history-item-title { font-size: 12.5px; color: #C4C4CE; }
        .history-item-time { font-size: 11px; color: #55555F; margin-top: 2px; }

        .panel-search-input {
          width: 100%; background: #17171C; border: 1px solid rgba(255,255,255,0.08);
          border-radius: 10px; padding: 10px 12px; color: #E4E4E9; font-size: 13px; outline: none;
        }

        .explore-group { margin-bottom: 18px; }
        .explore-group-title { font-size: 12px; font-weight: 600; margin-bottom: 8px; text-transform: uppercase; letter-spacing: 0.04em; }
        .explore-item { padding: 9px 8px; border-radius: 9px; cursor: pointer; transition: background 0.15s; }
        .explore-item:hover { background: rgba(255,255,255,0.05); }
        .explore-item-title { font-size: 13px; color: #E4E4E9; font-weight: 500; }
        .explore-item-desc { font-size: 11.5px; color: #63636D; margin-top: 2px; }

        .apps-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; }
        .app-tile {
          background: #17171C; border: 1px solid rgba(255,255,255,0.07); border-radius: 12px;
          padding: 16px 12px; font-size: 12px; color: #C4C4CE; cursor: pointer;
          transition: border-color 0.15s; text-align: center;
        }
        .app-tile:hover { border-color: rgba(139,124,255,0.3); }

        .panel-section { margin-bottom: 22px; }
        .panel-section-title { font-size: 11px; color: #4E4E58; text-transform: uppercase; letter-spacing: 0.05em; margin-bottom: 8px; }
        .settings-row { display: flex; align-items: center; justify-content: space-between; padding: 12px 0; border-bottom: 1px solid rgba(255,255,255,0.05); gap: 10px; }
        .settings-row-label { font-size: 13px; color: #E4E4E9; }
        .settings-row-desc { font-size: 11.5px; color: #63636D; margin-top: 2px; }

        .segmented { display: flex; background: #17171C; border-radius: 8px; padding: 2px; flex-shrink: 0; }
        .segmented button { background: transparent; border: none; color: #7A7A88; font-size: 12px; padding: 6px 11px; border-radius: 6px; cursor: pointer; }
        .seg-active { background: #26262E !important; color: #E4E4E9 !important; }

        .select { background: #17171C; border: 1px solid rgba(255,255,255,0.08); color: #E4E4E9; border-radius: 8px; padding: 6px 9px; font-size: 12px; outline: none; }
        .chips { display: flex; gap: 5px; flex-wrap: wrap; }
        .chip { font-size: 11px; padding: 4px 9px; border-radius: 20px; background: #17171C; color: #63636D; border: 1px solid rgba(255,255,255,0.06); }
        .chip-on { background: rgba(139,124,255,0.16); color: #C4B8FF; border-color: rgba(139,124,255,0.3); }

        .switch { position: relative; width: 36px; height: 21px; display: inline-block; flex-shrink: 0; }
        .switch input { opacity: 0; width: 0; height: 0; }
        .switch-slider { position: absolute; inset: 0; background: #26262E; border-radius: 20px; cursor: pointer; transition: 0.2s; }
        .switch-slider:before { content: ""; position: absolute; width: 15px; height: 15px; left: 3px; top: 3px; background: #8A8A96; border-radius: 50%; transition: 0.2s; }
        .switch input:checked + .switch-slider { background: rgba(139,124,255,0.5); }
        .switch input:checked + .switch-slider:before { transform: translateX(15px); background: #C4B8FF; }

        .btn-secondary { background: #17171C; border: 1px solid rgba(255,255,255,0.08); color: #C4C4CE; padding: 6px 13px; border-radius: 8px; font-size: 12px; cursor: pointer; }
        .btn-primary-sm { background: #E4E4E9; color: #0A0A0D; border: none; padding: 5px 12px; border-radius: 7px; font-size: 11.5px; font-weight: 600; cursor: pointer; }

        .profile-hero { display: flex; align-items: center; gap: 12px; margin-bottom: 22px; }
        .avatar-lg { width: 46px; height: 46px; border-radius: 13px; background: linear-gradient(135deg,#8B7CFF,#4C3FD9); display: flex; align-items: center; justify-content: center; font-size: 18px; font-weight: 600; color: white; }
        .profile-hero-name { font-size: 15.5px; font-weight: 600; }
        .profile-hero-sub { font-size: 12px; color: #63636D; margin-top: 2px; }

        .plan-card { background: #17171C; border: 1px solid rgba(255,255,255,0.06); border-radius: 12px; padding: 14px 16px; }
        .plan-card-top { display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px; }
        .plan-name { font-size: 13px; font-weight: 600; }
        .usage-row { display: flex; align-items: center; gap: 8px; font-size: 11.5px; color: #8A8A96; margin-bottom: 7px; }
        .usage-row span:first-child { width: 90px; flex-shrink: 0; }
        .usage-bar { flex: 1; height: 5px; background: #1D1D23; border-radius: 4px; overflow: hidden; }
        .usage-fill { height: 100%; background: #8B7CFF; border-radius: 4px; }
        .usage-count { width: 45px; flex-shrink: 0; text-align: right; color: #63636D; }

        .icon-14 { width: 14px; height: 14px; }
        .icon-15 { width: 15px; height: 15px; }
        .icon-16 { width: 16px; height: 16px; }

        /* ---------- Responsive ---------- */
        @media (max-width: 767px) {
          .app { padding: 8px; gap: 8px; }
          .icon-sidebar { width: 48px; padding: 10px 0; }
          .feature-cards { flex-direction: column; }
          .greeting h1 { font-size: 22px; }
          .side-panel { left: 62px; right: 8px; width: auto; max-width: none; }
          .composer-pills { overflow-x: auto; flex-wrap: nowrap; }
        }
      `}</style>

      <IconSidebar
        activePanel={activePanel}
        setActivePanel={setActivePanel}
        onNewResearch={() => { setResult(null); setQuery(""); setActivePanel(null); }}
      />

      <div className="main-view">
        {!hasContent && (
          <div className="center-wrap">
            <div className="greeting">
              <h1>Hi Logosi, <span className="accent">ready to build something great?</span></h1>
            </div>
            <div className="feature-cards">
              {FEATURE_CARDS.map((c, i) => {
                const CardIcon = c.icon;
                return (
                  <div key={i} className="feature-card">
                    <div className="feature-card-icon" style={{ background: c.iconBg }}>
                      <CardIcon className="icon-16" />
                    </div>
                    <div className="feature-card-title">{c.title}</div>
                    <div className="feature-card-tag">{c.tag}</div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {hasContent && (
          <div className="results">
            {loading && (
              <div className="trace">
                {STAGES.map((s, i) => {
                  const state = i < stageIdx ? "done" : i === stageIdx ? "active" : "pending";
                  return (
                    <div key={s} className={`trace-row trace-${state}`}>
                      <span className="trace-marker">{state === "done" ? "✓" : ""}</span>
                      <span>{s}</span>
                    </div>
                  );
                })}
              </div>
            )}
            {result && (
              <div className="card">
                <div className="tags">
                  <span className="tag tag-mode"><ModeDot mode={mainMode} />{MODE_CONFIG[mainMode].sub.find(s => s.key === subMode)?.label}</span>
                  <span className="tag tag-source">web</span>
                  <span className="tag tag-source">reddit</span>
                  <span className="tag tag-source">github</span>
                </div>
                <Report text={result.report} />
              </div>
            )}
          </div>
        )}

        <div className="composer-outer">
          <div className="composer-card">
            <div className="composer-topline">
              <span className="upgrade"><Icon.sparkle className="icon-14" /> Unlock more with Pro</span>
              <span>Research OS</span>
            </div>

            <div className="composer-inputrow">
              <div className="composer-left">
                <button className="attach-btn" onClick={() => setAttachOpen(!attachOpen)}>
                  <Icon.plus className="icon-16" />
                </button>
                <AttachMenu open={attachOpen} onClose={() => setAttachOpen(false)} />
              </div>
              <input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder='Example: "Should I build an AI note-taking startup?"'
                onKeyDown={(e) => { if (e.key === "Enter") handleSend(); }}
              />
              <div className="composer-right">
                <button className="round-btn"><Icon.mic className="icon-15" /></button>
                <button className="round-btn round-btn-send" onClick={handleSend} disabled={loading}>
                  <Icon.send className="icon-15" />
                </button>
              </div>
            </div>

            <div className="composer-pills">
              {Object.entries(MODE_CONFIG).map(([key, cfg]) => {
                const PillIcon = cfg.icon;
                return (
                  <div key={key} style={{ position: "relative" }}>
                    <button
                      className={`pill-btn ${mainMode === key ? "pill-btn-active" : ""}`}
                      onClick={() => setOpenPillMode(openPillMode === key ? null : key)}
                    >
                      <PillIcon className="pill-btn-icon" />
                      {mainMode === key ? MODE_CONFIG[key].sub.find(s => s.key === subMode)?.label : cfg.label}
                    </button>
                    <ModeExpandPopup
                      modeKey={key}
                      open={openPillMode === key}
                      onClose={() => setOpenPillMode(null)}
                      onSelect={handleModeSelect}
                    />
                  </div>
                );
              })}
              <button className="pill-more"><Icon.more className="icon-15" /></button>
            </div>
          </div>
        </div>
      </div>

      <SidePanel type={activePanel} onClose={() => setActivePanel(null)} />
    </div>
  );
}
