import React, { useState, useRef, useEffect } from "react";
import { ThemeProvider, useTheme, ACCENT_OPTIONS } from "./ThemeContext";

// ---------- Icons ----------
const Icon = {
  plus: (p) => (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" {...p}><path d="M12 5v14M5 12h14" strokeLinecap="round" /></svg>),
  search: (p) => (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" {...p}><circle cx="11" cy="11" r="7" /><path d="M21 21l-4.35-4.35" strokeLinecap="round" /></svg>),
  compass: (p) => (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" {...p}><circle cx="12" cy="12" r="10" /><path d="M16.24 7.76l-2.12 6.36-6.36 2.12 2.12-6.36 6.36-2.12z" strokeLinejoin="round" /></svg>),
  grid: (p) => (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" {...p}><rect x="3" y="3" width="7" height="7" rx="1.5" /><rect x="14" y="3" width="7" height="7" rx="1.5" /><rect x="3" y="14" width="7" height="7" rx="1.5" /><rect x="14" y="14" width="7" height="7" rx="1.5" /></svg>),
  history: (p) => (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" {...p}><path d="M3 12a9 9 0 1 0 3-6.7" strokeLinecap="round" strokeLinejoin="round" /><path d="M3 4v5h5" strokeLinecap="round" strokeLinejoin="round" /><path d="M12 7v5l3 3" strokeLinecap="round" strokeLinejoin="round" /></svg>),
  settings: (p) => (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" {...p}><circle cx="12" cy="12" r="3" /><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.6a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z" /></svg>),
  paperclip: (p) => (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" {...p}><path d="M21.44 11.05l-9.19 9.19a6 6 0 0 1-8.49-8.49l9.19-9.19a4 4 0 0 1 5.66 5.66l-9.2 9.19a2 2 0 0 1-2.83-2.83l8.49-8.48" strokeLinecap="round" strokeLinejoin="round" /></svg>),
  image: (p) => (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" {...p}><rect x="3" y="3" width="18" height="18" rx="2" /><circle cx="8.5" cy="8.5" r="1.5" /><path d="M21 15l-5-5L5 21" strokeLinecap="round" strokeLinejoin="round" /></svg>),
  camera: (p) => (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" {...p}><path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z" strokeLinecap="round" strokeLinejoin="round" /><circle cx="12" cy="13" r="4" /></svg>),
  send: (p) => (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" {...p}><path d="M22 2L11 13M22 2l-7 20-4-9-9-4z" strokeLinecap="round" strokeLinejoin="round" /></svg>),
  arrowUp: (p) => (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" {...p}><path d="M12 19V5M5 12l7-7 7 7" strokeLinecap="round" strokeLinejoin="round" /></svg>),
  mic: (p) => (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" {...p}><path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z" /><path d="M19 10v2a7 7 0 0 1-14 0v-2M12 19v4M8 23h8" strokeLinecap="round" /></svg>),
  sparkle: (p) => (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" {...p}><path d="M12 3v4M12 17v4M3 12h4M17 12h4M5.6 5.6l2.8 2.8M15.6 15.6l2.8 2.8M18.4 5.6l-2.8 2.8M8.4 15.6l-2.8 2.8" strokeLinecap="round" /></svg>),
  layers: (p) => (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" {...p}><path d="M12 2l9 5-9 5-9-5 9-5z" strokeLinejoin="round" /><path d="M3 12l9 5 9-5M3 17l9 5 9-5" strokeLinecap="round" strokeLinejoin="round" /></svg>),
  map: (p) => (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" {...p}><path d="M9 20l-6-3V4l6 3 6-3 6 3v13l-6-3-6 3z" strokeLinejoin="round" /><path d="M9 7v13M15 4v13" /></svg>),
  target: (p) => (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" {...p}><circle cx="12" cy="12" r="9" /><circle cx="12" cy="12" r="5" /><circle cx="12" cy="12" r="1" /></svg>),
  close: (p) => (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" {...p}><path d="M18 6L6 18M6 6l12 12" strokeLinecap="round" /></svg>),
  chevron: (p) => (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" {...p}><path d="M6 9l6 6 6-6" strokeLinecap="round" /></svg>),
  more: (p) => (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" {...p}><circle cx="5" cy="12" r="1.5" /><circle cx="12" cy="12" r="1.5" /><circle cx="19" cy="12" r="1.5" /></svg>),
  menu: (p) => (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" {...p}><path d="M3 6h18M3 12h18M3 18h18" strokeLinecap="round" /></svg>),
  panelExpand: (p) => (<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" {...p}><rect x="3" y="4" width="18" height="16" rx="2" /><path d="M9 4v16" /></svg>),
};

const MODE_CONFIG = {
  ask: { label: "Ask", icon: Icon.sparkle, sub: [
    { key: "ask", label: "Ask", desc: "Quick answer, fast model" },
    { key: "ask_thinking", label: "Ask + Thinking", desc: "Reasons before answering" },
  ]},
  research: { label: "Research", icon: Icon.search, sub: [
    { key: "research", label: "Research", desc: "Multi-source search & summary" },
    { key: "deep_research", label: "Deep Research + Thinking", desc: "Patterns, contradictions, insight" },
  ]},
  plan: { label: "Plan", icon: Icon.map, sub: [
    { key: "plan", label: "Plan", desc: "Straightforward action plan" },
    { key: "deep_plan", label: "Deep Plan + Thinking", desc: "Full strategy with tradeoffs" },
  ]},
};

const FEATURE_CARDS = [
  { icon: Icon.layers, title: "Validate a startup idea before you build it.", tag: "Startup Validation" },
  { icon: Icon.target, title: "Compare tech stacks with real GitHub signals.", tag: "Technology Research" },
  { icon: Icon.map, title: "Analyze a competitor's pricing and moat.", tag: "Competitor Research" },
];

const HISTORY = [
  { id: 1, title: "AI note-taking startup validation", time: "2h ago" },
  { id: 2, title: "Next.js vs Svelte for SaaS", time: "Yesterday" },
  { id: 3, title: "Cursor pricing and moat analysis", time: "Yesterday" },
  { id: 4, title: "Developer sentiment on Bun", time: "3 days ago" },
];

const STAGES = ["Understanding intent", "Selecting sources", "Collecting data", "Finding patterns", "Generating insight"];

const SAMPLE_REPORT = `## Summary
AI note-taking is a crowded space, but most incumbents optimize for consumers, not founders who need research-grade memory.

## Key Findings
- Notion, Obsidian, and Mem dominate mindshare but skew toward general productivity.
- Reddit complaints cluster around search quality and AI accuracy, not feature count.

## Patterns
- Every major complaint across sources is retrieval quality, not UI polish.

## Opportunities
- A founder-only memory layer tied to research and decisions, not generic notes.

## Recommendation
Build a narrow wedge: memory linked to research sessions, not a general notes app.`;

function Report({ text }) {
  const lines = text.split("\n");
  return (
    <div className="report">
      {lines.map((line, i) => {
        if (line.startsWith("## ")) return <h2 key={i}>{line.replace("## ", "")}</h2>;
        if (line.trim().startsWith("- ")) return <li key={i}>{line.trim().replace(/^- /, "")}</li>;
        if (line.trim() === "") return <div key={i} className="spacer" />;
        return <p key={i}>{line}</p>;
      })}
    </div>
  );
}

// ---------- Desktop sidebar (slim <-> expanded) ----------
function DesktopSidebar({ expanded, setExpanded, activePanel, setActivePanel, onNewResearch }) {
  const NAV = [
    { key: "search", icon: Icon.search, label: "Search" },
    { key: "explore", icon: Icon.compass, label: "Explore modes" },
    { key: "apps", icon: Icon.grid, label: "Micro-tools" },
    { key: "history", icon: Icon.history, label: "History" },
  ];

  return (
    <aside className={`desktop-sidebar ${expanded ? "desktop-sidebar-expanded" : ""}`}>
      <div className="ds-top">
        <button className="ds-plus" onClick={onNewResearch} title="New research">
          <Icon.plus className="icon-16" />
          {expanded && <span>New research</span>}
        </button>
        <button className="ds-expand-toggle" onClick={() => setExpanded(!expanded)} title="Toggle sidebar width">
          <Icon.panelExpand className="icon-15" />
        </button>
      </div>

      <div className="ds-nav">
        {NAV.map((n) => (
          <button
            key={n.key}
            className={`ds-nav-btn ${activePanel === n.key ? "ds-nav-btn-active" : ""}`}
            onClick={() => setActivePanel(activePanel === n.key ? null : n.key)}
          >
            <n.icon className="icon-16" />
            {expanded && <span>{n.label}</span>}
          </button>
        ))}
      </div>

      {expanded && (
        <div className="ds-recent">
          <div className="ds-recent-label">Recent</div>
          {HISTORY.slice(0, 4).map((h) => (
            <div key={h.id} className="ds-recent-item">
              <span className="mode-dot" />
              <span className="ds-recent-title">{h.title}</span>
            </div>
          ))}
        </div>
      )}

      <div className="ds-spacer" />

      <button
        className={`ds-nav-btn ${activePanel === "settings" ? "ds-nav-btn-active" : ""}`}
        onClick={() => setActivePanel(activePanel === "settings" ? null : "settings")}
      >
        <Icon.settings className="icon-15" />
        {expanded && <span>Settings</span>}
      </button>
      <button className="ds-profile" onClick={() => setActivePanel("profile")}>
        <span className="ds-avatar">L</span>
        {expanded && (
          <div className="ds-profile-text">
            <div className="ds-profile-name">Logosi</div>
            <div className="ds-profile-plan">Free plan</div>
          </div>
        )}
      </button>
    </aside>
  );
}

// ---------- Mobile top header + drawer ----------
function MobileHeader({ onOpenMenu }) {
  return (
    <div className="mobile-header">
      <button className="icon-btn-sm" onClick={onOpenMenu}><Icon.menu className="icon-18" /></button>
      <div className="mobile-brand">Research OS</div>
      <button className="mobile-avatar">L</button>
    </div>
  );
}

function MobileDrawer({ open, onClose, setActivePanel, onNewResearch }) {
  const NAV = [
    { key: "search", icon: Icon.search, label: "Search" },
    { key: "explore", icon: Icon.compass, label: "Explore modes" },
    { key: "apps", icon: Icon.grid, label: "Micro-tools" },
    { key: "history", icon: Icon.history, label: "History" },
    { key: "settings", icon: Icon.settings, label: "Settings" },
  ];
  return (
    <>
      {open && <div className="drawer-overlay" onClick={onClose} />}
      <div className={`mobile-drawer ${open ? "mobile-drawer-open" : ""}`}>
        <div className="mobile-drawer-header">
          <span className="mobile-brand">Research OS</span>
          <button className="icon-btn-sm" onClick={onClose}><Icon.close className="icon-16" /></button>
        </div>

        <button className="ds-plus" style={{ width: "100%", marginBottom: 16 }} onClick={() => { onNewResearch(); onClose(); }}>
          <Icon.plus className="icon-16" /> <span>New research</span>
        </button>

        <div className="mobile-drawer-nav">
          {NAV.map((n) => (
            <button key={n.key} className="ds-nav-btn" style={{ width: "100%", justifyContent: "flex-start" }} onClick={() => { setActivePanel(n.key); onClose(); }}>
              <n.icon className="icon-16" /> <span>{n.label}</span>
            </button>
          ))}
        </div>

        <div className="mobile-drawer-recent">
          <div className="ds-recent-label">Recent</div>
          {HISTORY.map((h) => (
            <div key={h.id} className="ds-recent-item">
              <span className="mode-dot" />
              <span className="ds-recent-title">{h.title}</span>
            </div>
          ))}
        </div>

        <button className="mobile-drawer-profile" onClick={() => { setActivePanel("profile"); onClose(); }}>
          <span className="ds-avatar">L</span>
          <div className="ds-profile-text">
            <div className="ds-profile-name">Logosi</div>
            <div className="ds-profile-plan">Free plan</div>
          </div>
        </button>
      </div>
    </>
  );
}

// ---------- Side panel (History / Explore / Apps / Settings / Profile) ----------
function SidePanel({ type, onClose, isMobile }) {
  const { mode, setMode, accentKey, setAccentKey } = useTheme();
  if (!type) return null;

  return (
    <>
      <div className="panel-overlay" onClick={onClose} />
      <div className={`side-panel ${isMobile ? "side-panel-mobile" : ""}`}>
        <div className="side-panel-header">
          <h2>
            {type === "history" && "Research history"}
            {type === "search" && "Search"}
            {type === "explore" && "Research modes"}
            {type === "apps" && "Micro-tools"}
            {type === "settings" && "Settings"}
            {type === "profile" && "Profile"}
          </h2>
          <button className="icon-btn-sm" onClick={onClose}><Icon.close className="icon-16" /></button>
        </div>

        <div className="side-panel-body">
          {type === "history" && (
            <div className="history-list">
              {HISTORY.map((h) => (
                <div key={h.id} className="history-item">
                  <span className="mode-dot" />
                  <div className="history-item-text">
                    <div className="history-item-title">{h.title}</div>
                    <div className="history-item-time">{h.time}</div>
                  </div>
                </div>
              ))}
            </div>
          )}

          {type === "search" && (
            <input className="panel-search-input" placeholder="Search past research..." autoFocus />
          )}

          {type === "explore" && (
            <div className="explore-list">
              {Object.entries(MODE_CONFIG).map(([key, cfg]) => (
                <div key={key} className="explore-group">
                  <div className="explore-group-title">{cfg.label}</div>
                  {cfg.sub.map((s) => (
                    <div key={s.key} className="explore-item">
                      <div className="explore-item-title">{s.label}</div>
                      <div className="explore-item-desc">{s.desc}</div>
                    </div>
                  ))}
                </div>
              ))}
            </div>
          )}

          {type === "apps" && (
            <div className="apps-grid">
              {["Competitor Tracker", "Pricing Benchmark", "GitHub Activity Check", "Reddit Sentiment", "Market Sizing", "Idea Validator"].map((a) => (
                <div key={a} className="app-tile">{a}</div>
              ))}
            </div>
          )}

          {type === "settings" && (
            <>
              <div className="panel-section">
                <div className="panel-section-title">Appearance</div>
                <div className="settings-row">
                  <div>
                    <div className="settings-row-label">Theme</div>
                    <div className="settings-row-desc">Interface color mode</div>
                  </div>
                  <div className="segmented">
                    <button className={mode === "dark" ? "seg-active" : ""} onClick={() => setMode("dark")}>Dark</button>
                    <button className={mode === "light" ? "seg-active" : ""} onClick={() => setMode("light")}>Light</button>
                  </div>
                </div>
                <div className="settings-row" style={{ flexDirection: "column", alignItems: "flex-start", gap: 10 }}>
                  <div>
                    <div className="settings-row-label">Accent color</div>
                    <div className="settings-row-desc">Used for highlights and active states</div>
                  </div>
                  <div className="accent-row">
                    {Object.entries(ACCENT_OPTIONS).map(([key, a]) => (
                      <button
                        key={key}
                        className={`accent-swatch ${accentKey === key ? "accent-swatch-active" : ""}`}
                        style={{ background: a.value }}
                        onClick={() => setAccentKey(key)}
                        title={a.name}
                      />
                    ))}
                  </div>
                </div>
              </div>

              <div className="panel-section">
                <div className="panel-section-title">Research defaults</div>
                <div className="settings-row">
                  <div>
                    <div className="settings-row-label">Default mode</div>
                    <div className="settings-row-desc">Used for new research</div>
                  </div>
                  <select className="select" defaultValue="research">
                    <option value="ask">Ask</option>
                    <option value="research">Research</option>
                    <option value="plan">Plan</option>
                  </select>
                </div>
                <div className="settings-row">
                  <div>
                    <div className="settings-row-label">Sources</div>
                    <div className="settings-row-desc">Included by default</div>
                  </div>
                  <div className="chips">
                    <span className="chip chip-on">Web</span>
                    <span className="chip chip-on">Reddit</span>
                    <span className="chip chip-on">GitHub</span>
                    <span className="chip">News</span>
                  </div>
                </div>
              </div>

              <div className="panel-section">
                <div className="panel-section-title">Notifications</div>
                <div className="settings-row">
                  <div>
                    <div className="settings-row-label">Email updates</div>
                    <div className="settings-row-desc">Usage summaries, product news</div>
                  </div>
                  <label className="switch">
                    <input type="checkbox" defaultChecked />
                    <span className="switch-slider" />
                  </label>
                </div>
              </div>
            </>
          )}

          {type === "profile" && (
            <>
              <div className="profile-hero">
                <div className="avatar-lg">L</div>
                <div>
                  <div className="profile-hero-name">Logosi</div>
                  <div className="profile-hero-sub">Builder · Logrith</div>
                </div>
              </div>
              <div className="panel-section">
                <div className="panel-section-title">Account</div>
                <div className="settings-row">
                  <div>
                    <div className="settings-row-label">Email</div>
                    <div className="settings-row-desc">logosi@logrith.in</div>
                  </div>
                  <button className="btn-secondary">Change</button>
                </div>
              </div>
              <div className="panel-section">
                <div className="panel-section-title">Plan & usage</div>
                <div className="plan-card">
                  <div className="plan-card-top">
                    <span className="plan-name">Free Plan</span>
                    <button className="btn-primary-sm">Upgrade</button>
                  </div>
                  <div className="usage-row"><span>Research</span><div className="usage-bar"><div className="usage-fill" style={{ width: "60%" }} /></div><span className="usage-count">6/10</span></div>
                  <div className="usage-row"><span>Deep Research</span><div className="usage-bar"><div className="usage-fill" style={{ width: "0%" }} /></div><span className="usage-count">0/2</span></div>
                </div>
              </div>
            </>
          )}
        </div>
      </div>
    </>
  );
}

// ---------- Attach popup ----------
function AttachMenu({ open, onClose }) {
  const ref = useRef(null);
  useEffect(() => {
    function onClick(e) { if (ref.current && !ref.current.contains(e.target)) onClose(); }
    if (open) document.addEventListener("mousedown", onClick);
    return () => document.removeEventListener("mousedown", onClick);
  }, [open, onClose]);
  if (!open) return null;
  return (
    <div className="attach-popup" ref={ref}>
      <div className="attach-item"><Icon.paperclip className="icon-15" /> Attach file</div>
      <div className="attach-item"><Icon.image className="icon-15" /> Attach image</div>
      <div className="attach-item"><Icon.camera className="icon-15" /> Camera</div>
    </div>
  );
}

// ---------- Compact mode dropdown (Perplexity-style, used on mobile composer) ----------
function ModeDropdownCompact({ mainMode, subMode, onSelect }) {
  const [open, setOpen] = useState(false);
  const ref = useRef(null);
  useEffect(() => {
    function onClick(e) { if (ref.current && !ref.current.contains(e.target)) setOpen(false); }
    document.addEventListener("mousedown", onClick);
    return () => document.removeEventListener("mousedown", onClick);
  }, []);
  const cfg = MODE_CONFIG[mainMode];
  const ModeIcon = cfg.icon;

  return (
    <div className="mode-compact-wrap" ref={ref}>
      <button className="mode-compact-btn" onClick={() => setOpen(!open)}>
        <ModeIcon className="icon-14" />
        <Icon.chevron className="icon-11" />
      </button>
      {open && (
        <div className="mode-compact-popup">
          {Object.entries(MODE_CONFIG).map(([key, c]) => (
            <div key={key} className="mode-compact-group">
              <div className="mode-compact-group-label">{c.label}</div>
              {c.sub.map((s) => (
                <div
                  key={s.key}
                  className={`mode-pill-item ${subMode === s.key ? "mode-pill-item-active" : ""}`}
                  onClick={() => { onSelect(key, s.key); setOpen(false); }}
                >
                  <div className="mode-pill-item-title">{s.label}</div>
                  <div className="mode-pill-item-desc">{s.desc}</div>
                </div>
              ))}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ---------- Mode pill popup (desktop, for pill buttons) ----------
function ModeExpandPopup({ modeKey, open, onClose, onSelect }) {
  const ref = useRef(null);
  useEffect(() => {
    function onClick(e) { if (ref.current && !ref.current.contains(e.target)) onClose(); }
    if (open) document.addEventListener("mousedown", onClick);
    return () => document.removeEventListener("mousedown", onClick);
  }, [open, onClose]);
  if (!open) return null;
  const cfg = MODE_CONFIG[modeKey];
  return (
    <div className="mode-expand-popup" ref={ref}>
      {cfg.sub.map((s) => (
        <div key={s.key} className="mode-pill-item" onClick={() => { onSelect(modeKey, s.key); onClose(); }}>
          <div className="mode-pill-item-title">{s.label}</div>
          <div className="mode-pill-item-desc">{s.desc}</div>
        </div>
      ))}
    </div>
  );
}

function AppShell() {
  const [isMobile, setIsMobile] = useState(false);
  const [sidebarExpanded, setSidebarExpanded] = useState(false);
  const [mobileDrawerOpen, setMobileDrawerOpen] = useState(false);
  const [activePanel, setActivePanel] = useState(null);
  const [query, setQuery] = useState("");
  const [mainMode, setMainMode] = useState("research");
  const [subMode, setSubMode] = useState("research");
  const [attachOpen, setAttachOpen] = useState(false);
  const [openPillMode, setOpenPillMode] = useState(null);
  const [loading, setLoading] = useState(false);
  const [stageIdx, setStageIdx] = useState(0);
  const [result, setResult] = useState(null);
  const timerRef = useRef(null);

  useEffect(() => {
    function check() { setIsMobile(window.innerWidth < 768); }
    check();
    window.addEventListener("resize", check);
    return () => window.removeEventListener("resize", check);
  }, []);

  function handleModeSelect(main, sub) { setMainMode(main); setSubMode(sub); }

  function handleSend() {
    if (!query.trim() || loading) return;
    setResult(null);
    setLoading(true);
    setStageIdx(0);
    let i = 0;
    timerRef.current = setInterval(() => {
      i += 1;
      setStageIdx(i);
      if (i >= STAGES.length - 1) {
        clearInterval(timerRef.current);
        setTimeout(() => { setLoading(false); setResult({ report: SAMPLE_REPORT }); }, 500);
      }
    }, 400);
  }

  useEffect(() => () => clearInterval(timerRef.current), []);
  const hasContent = loading || result;

  return (
    <div className="app">
      <style>{GLOBAL_STYLES}</style>

      {!isMobile && (
        <DesktopSidebar
          expanded={sidebarExpanded}
          setExpanded={setSidebarExpanded}
          activePanel={activePanel}
          setActivePanel={setActivePanel}
          onNewResearch={() => { setResult(null); setQuery(""); setActivePanel(null); }}
        />
      )}

      <div className="main-view">
        {isMobile && <MobileHeader onOpenMenu={() => setMobileDrawerOpen(true)} />}

        {!hasContent && (
          <div className="center-wrap">
            <div className="greeting">
              <h1>Hi Logosi, <span className="accent-text">ready to build something great?</span></h1>
            </div>
            <div className="feature-cards">
              {FEATURE_CARDS.map((c, i) => {
                const CardIcon = c.icon;
                return (
                  <div key={i} className="feature-card">
                    <div className="feature-card-icon"><CardIcon className="icon-16" /></div>
                    <div className="feature-card-title">{c.title}</div>
                    <div className="feature-card-tag">{c.tag}</div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {hasContent && (
          <div className="results">
            {loading && (
              <div className="trace">
                {STAGES.map((s, i) => {
                  const state = i < stageIdx ? "done" : i === stageIdx ? "active" : "pending";
                  return (
                    <div key={s} className={`trace-row trace-${state}`}>
                      <span className="trace-marker">{state === "done" ? "✓" : ""}</span>
                      <span>{s}</span>
                    </div>
                  );
                })}
              </div>
            )}
            {result && (
              <div className="card">
                <div className="tags">
                  <span className="tag tag-mode"><span className="mode-dot" />{MODE_CONFIG[mainMode].sub.find(s => s.key === subMode)?.label}</span>
                  <span className="tag tag-source">web</span>
                  <span className="tag tag-source">reddit</span>
                  <span className="tag tag-source">github</span>
                </div>
                <Report text={result.report} />
              </div>
            )}
          </div>
        )}

        {!isMobile && (
          <div className="composer-outer">
            <div className="composer-card">
              <div className="composer-topline">
                <span className="upgrade"><Icon.sparkle className="icon-14" /> Unlock more with Pro</span>
                <span>Research OS</span>
              </div>
              <div className="composer-inputrow">
                <div className="composer-left">
                  <button className="attach-btn" onClick={() => setAttachOpen(!attachOpen)}><Icon.plus className="icon-16" /></button>
                  <AttachMenu open={attachOpen} onClose={() => setAttachOpen(false)} />
                </div>
                <input
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder='Example: "Should I build an AI note-taking startup?"'
                  onKeyDown={(e) => { if (e.key === "Enter") handleSend(); }}
                />
                <div className="composer-right">
                  <button className="round-btn"><Icon.mic className="icon-15" /></button>
                  <button className="round-btn round-btn-send" onClick={handleSend} disabled={loading}><Icon.send className="icon-15" /></button>
                </div>
              </div>
              <div className="composer-pills">
                {Object.entries(MODE_CONFIG).map(([key, cfg]) => {
                  const PillIcon = cfg.icon;
                  return (
                    <div key={key} style={{ position: "relative" }}>
                      <button className={`pill-btn ${mainMode === key ? "pill-btn-active" : ""}`} onClick={() => setOpenPillMode(openPillMode === key ? null : key)}>
                        <PillIcon className="pill-btn-icon" />
                        {mainMode === key ? MODE_CONFIG[key].sub.find(s => s.key === subMode)?.label : cfg.label}
                      </button>
                      <ModeExpandPopup modeKey={key} open={openPillMode === key} onClose={() => setOpenPillMode(null)} onSelect={handleModeSelect} />
                    </div>
                  );
                })}
                <button className="pill-more"><Icon.more className="icon-15" /></button>
              </div>
            </div>
          </div>
        )}

        {isMobile && (
          <div className="mobile-composer-wrap">
            <div className="mobile-composer">
              <input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="What do you want to know?"
                onKeyDown={(e) => { if (e.key === "Enter") handleSend(); }}
              />
              <div className="mobile-composer-row">
                <div className="mobile-composer-left">
                  <button className="attach-btn attach-btn-mobile" onClick={() => setAttachOpen(!attachOpen)}><Icon.plus className="icon-16" /></button>
                  <AttachMenu open={attachOpen} onClose={() => setAttachOpen(false)} />
                  <ModeDropdownCompact mainMode={mainMode} subMode={subMode} onSelect={handleModeSelect} />
                </div>
                <div className="mobile-composer-right">
                  <button className="round-btn"><Icon.mic className="icon-15" /></button>
                  <button className="round-btn round-btn-send" onClick={handleSend} disabled={loading}><Icon.arrowUp className="icon-15" /></button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {isMobile && (
        <MobileDrawer
          open={mobileDrawerOpen}
          onClose={() => setMobileDrawerOpen(false)}
          setActivePanel={setActivePanel}
          onNewResearch={() => { setResult(null); setQuery(""); }}
        />
      )}

      <SidePanel type={activePanel} onClose={() => setActivePanel(null)} isMobile={isMobile} />
    </div>
  );
}

const GLOBAL_STYLES = `
  @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap');
  * { box-sizing: border-box; margin: 0; padding: 0; }
  html, body, #root { height: 100%; }
  .app {
    display: flex; height: 100vh; width: 100%;
    background:
      radial-gradient(ellipse 70% 50% at 20% 0%, var(--bgGradientA), transparent),
      radial-gradient(ellipse 60% 40% at 90% 10%, var(--bgGradientB), transparent),
      var(--bg);
    color: var(--text); font-family: 'Inter', -apple-system, sans-serif;
    overflow: hidden; position: relative; padding: 14px; gap: 14px;
    transition: background 0.2s;
  }

  .desktop-sidebar {
    width: 56px; flex-shrink: 0; background: var(--surface);
    border: 1px solid var(--border); border-radius: 20px;
    display: flex; flex-direction: column; padding: 14px 8px; gap: 4px;
    transition: width 0.2s ease; overflow: hidden;
  }
  .desktop-sidebar-expanded { width: 220px; }

  .ds-top { display: flex; align-items: center; gap: 6px; margin-bottom: 10px; }
  .ds-plus {
    flex: 1; display: flex; align-items: center; gap: 8px; justify-content: center;
    height: 34px; border-radius: 10px; border: none;
    background: var(--text); color: var(--bg); cursor: pointer;
    font-size: 12.5px; font-weight: 500; transition: filter 0.15s;
    white-space: nowrap; overflow: hidden;
  }
  .desktop-sidebar-expanded .ds-plus { justify-content: flex-start; padding: 0 12px; }
  .ds-plus:hover { filter: brightness(0.9); }
  .ds-expand-toggle {
    width: 30px; height: 34px; border-radius: 9px; border: none; background: transparent;
    color: var(--textFaint); display: flex; align-items: center; justify-content: center;
    cursor: pointer; flex-shrink: 0; transition: background 0.15s, color 0.15s;
  }
  .ds-expand-toggle:hover { background: var(--inputBg); color: var(--text); }

  .ds-nav { display: flex; flex-direction: column; gap: 2px; }
  .ds-nav-btn {
    display: flex; align-items: center; gap: 10px; height: 36px; border-radius: 10px;
    border: none; background: transparent; color: var(--textMuted); cursor: pointer;
    font-size: 13px; padding: 0 8px; white-space: nowrap; overflow: hidden;
    transition: background 0.15s, color 0.15s;
  }
  .ds-nav-btn:hover { background: var(--inputBg); color: var(--text); }
  .ds-nav-btn-active { background: var(--accent-soft); color: var(--accent); }

  .ds-recent { margin-top: 14px; padding: 0 4px; overflow-y: auto; flex: 1; }
  .ds-recent-label { font-size: 10.5px; color: var(--textFainter); text-transform: uppercase; letter-spacing: 0.06em; padding: 4px 4px 8px; }
  .ds-recent-item { display: flex; align-items: center; gap: 8px; padding: 7px 6px; border-radius: 8px; cursor: pointer; transition: background 0.15s; }
  .ds-recent-item:hover { background: var(--inputBg); }
  .ds-recent-title { font-size: 12px; color: var(--textMuted); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }

  .ds-spacer { flex: 1; }
  .ds-profile { display: flex; align-items: center; gap: 9px; height: 40px; border-radius: 10px; border: none; background: transparent; cursor: pointer; padding: 0 6px; transition: background 0.15s; overflow: hidden; }
  .ds-profile:hover { background: var(--inputBg); }
  .ds-avatar { width: 26px; height: 26px; border-radius: 8px; background: var(--accent); color: white; font-size: 11px; font-weight: 600; display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
  .ds-profile-text { text-align: left; white-space: nowrap; overflow: hidden; }
  .ds-profile-name { font-size: 12px; color: var(--text); }
  .ds-profile-plan { font-size: 10.5px; color: var(--textFainter); }

  .mobile-header { display: flex; align-items: center; justify-content: space-between; padding: 8px 4px 12px; }
  .mobile-brand { font-size: 14px; font-weight: 600; }
  .mobile-avatar { width: 28px; height: 28px; border-radius: 8px; background: var(--accent); color: white; border: none; font-size: 11px; font-weight: 600; cursor: pointer; }

  .mobile-drawer {
    position: fixed; top: 0; left: 0; height: 100%; width: 280px; max-width: 82vw;
    background: var(--surfaceAlt); border-right: 1px solid var(--border);
    z-index: 90; transform: translateX(-100%); transition: transform 0.25s ease;
    display: flex; flex-direction: column; padding: 16px;
  }
  .mobile-drawer-open { transform: translateX(0); }
  .mobile-drawer-header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 16px; }
  .mobile-drawer-nav { display: flex; flex-direction: column; gap: 2px; }
  .mobile-drawer-recent { margin-top: 16px; flex: 1; overflow-y: auto; }
  .mobile-drawer-profile { display: flex; align-items: center; gap: 10px; border: none; background: var(--inputBg); border-radius: 10px; padding: 10px; cursor: pointer; margin-top: 8px; }
  .drawer-overlay { position: fixed; inset: 0; background: var(--overlay); z-index: 85; }

  .main-view {
    flex: 1; display: flex; flex-direction: column; overflow: hidden;
    border: 1px solid var(--border); border-radius: 20px;
    background: var(--surfaceAlt); position: relative; min-width: 0;
    transition: background 0.2s, border-color 0.2s;
  }

  .center-wrap { flex: 1; overflow-y: auto; display: flex; flex-direction: column; align-items: center; justify-content: center; padding: 24px; }

  .greeting { text-align: center; margin-bottom: 32px; }
  .greeting h1 { font-size: 28px; font-weight: 600; letter-spacing: -0.02em; line-height: 1.25; }
  .accent-text { color: var(--accent); }

  .feature-cards { display: flex; gap: 12px; max-width: 780px; width: 100%; }
  .feature-card {
    flex: 1; background: var(--surface); border: 1px solid var(--border);
    border-radius: 16px; padding: 18px; cursor: pointer;
    transition: border-color 0.15s, transform 0.15s;
  }
  .feature-card:hover { border-color: var(--accent); transform: translateY(-2px); }
  .feature-card-icon {
    width: 34px; height: 34px; border-radius: 10px; display: flex;
    align-items: center; justify-content: center; color: var(--accent);
    background: var(--accent-soft); margin-bottom: 14px;
  }
  .feature-card-title { font-size: 13px; line-height: 1.5; color: var(--text); margin-bottom: 12px; min-height: 58px; }
  .feature-card-tag { font-size: 10.5px; color: var(--textFaint); font-family: 'JetBrains Mono', monospace; }

  .results { flex: 1; overflow-y: auto; padding: 20px 24px 8px; max-width: 760px; margin: 0 auto; width: 100%; }

  .trace { background: var(--surface); border: 1px solid var(--border); border-radius: 14px; padding: 16px 18px; margin-bottom: 16px; }
  .trace-row { display: flex; align-items: center; gap: 10px; padding: 6px 0; font-size: 13px; color: var(--textFainter); transition: color 0.3s; }
  .trace-row.trace-active { color: var(--text); }
  .trace-row.trace-done { color: var(--accent); }
  .trace-marker { width: 15px; height: 15px; border-radius: 50%; border: 1.5px solid var(--border); display: flex; align-items: center; justify-content: center; font-size: 9px; flex-shrink: 0; }
  .trace-done .trace-marker { border-color: var(--accent); background: var(--accent-soft); }
  .trace-active .trace-marker { border-color: var(--accent); background: var(--accent); animation: pulse 1s infinite; }
  @keyframes pulse { 0%, 100% { box-shadow: 0 0 0 0 var(--accent-soft); } 50% { box-shadow: 0 0 0 5px transparent; } }

  .card { background: var(--surface); border: 1px solid var(--border); border-radius: 16px; padding: 22px 24px; }
  .tags { display: flex; gap: 6px; flex-wrap: wrap; margin-bottom: 16px; }
  .tag { font-family: 'JetBrains Mono', monospace; font-size: 10.5px; padding: 4px 9px; border-radius: 6px; display: inline-flex; align-items: center; gap: 5px; }
  .tag-mode { background: var(--accent-soft); color: var(--accent); }
  .tag-source { background: var(--inputBg); color: var(--textFaint); }
  .mode-dot { width: 6px; height: 6px; border-radius: 50%; flex-shrink: 0; background: var(--accent); }

  .report h2 { font-size: 14px; font-weight: 600; color: var(--accent); margin: 16px 0 7px; }
  .report h2:first-child { margin-top: 0; }
  .report p, .report li { font-size: 13.5px; line-height: 1.65; color: var(--textMuted); margin-bottom: 4px; }
  .report li { margin-left: 18px; }
  .spacer { height: 2px; }

  .composer-outer { max-width: 760px; margin: 0 auto 18px; width: 100%; padding: 0 18px; }
  .composer-card { background: var(--surface); border: 1px solid var(--border); border-radius: 18px; padding: 10px 14px; }
  .composer-topline { display: flex; align-items: center; justify-content: space-between; padding: 2px 4px 8px; font-size: 11px; color: var(--textFainter); }
  .composer-topline .upgrade { color: var(--accent); display: flex; align-items: center; gap: 5px; }

  .composer-inputrow { display: flex; align-items: center; gap: 8px; padding: 4px 2px; }
  .composer-left { position: relative; }
  .attach-btn {
    width: 30px; height: 30px; border-radius: 50%; background: var(--inputBg);
    border: none; color: var(--textFaint); display: flex; align-items: center; justify-content: center;
    cursor: pointer; flex-shrink: 0; transition: background 0.15s, color 0.15s;
  }
  .attach-btn:hover { background: var(--borderStrong); color: var(--text); }
  .attach-popup {
    position: absolute; bottom: calc(100% + 8px); left: 0;
    background: var(--surfaceRaised); border: 1px solid var(--borderStrong);
    border-radius: 10px; padding: 5px; width: 170px;
    box-shadow: 0 12px 32px -8px rgba(0,0,0,0.5); z-index: 30;
  }
  .attach-item { display: flex; align-items: center; gap: 9px; padding: 8px 9px; border-radius: 7px; cursor: pointer; font-size: 12.5px; color: var(--text); transition: background 0.15s; }
  .attach-item:hover { background: var(--inputBg); }

  .composer-inputrow input { flex: 1; background: transparent; border: none; outline: none; color: var(--text); font-size: 14px; font-family: inherit; min-width: 0; }
  .composer-inputrow input::placeholder { color: var(--textFainter); }

  .composer-right { display: flex; align-items: center; gap: 6px; }
  .round-btn {
    width: 30px; height: 30px; border-radius: 50%; border: none;
    background: var(--inputBg); color: var(--textFaint);
    display: flex; align-items: center; justify-content: center; cursor: pointer;
    transition: background 0.15s, color 0.15s; flex-shrink: 0;
  }
  .round-btn:hover { background: var(--borderStrong); color: var(--text); }
  .round-btn-send { background: var(--text); color: var(--bg); }
  .round-btn-send:hover { background: var(--text); filter: brightness(0.94); }
  .round-btn-send:disabled { opacity: 0.35; cursor: default; }

  .composer-pills { display: flex; gap: 7px; flex-wrap: wrap; padding: 10px 2px 2px; position: relative; }
  .pill-btn {
    display: flex; align-items: center; gap: 6px;
    background: var(--inputBg); border: 1px solid var(--border);
    color: var(--textMuted); padding: 7px 12px; border-radius: 20px;
    font-size: 12px; cursor: pointer; transition: background 0.15s, border-color 0.15s;
    white-space: nowrap;
  }
  .pill-btn:hover { background: var(--borderStrong); }
  .pill-btn-active { background: var(--accent-soft); border-color: var(--accent); color: var(--accent); }
  .pill-btn-icon { width: 13px; height: 13px; }
  .pill-more {
    width: 30px; height: 30px; border-radius: 50%; background: var(--inputBg);
    border: 1px solid var(--border); color: var(--textFaint);
    display: flex; align-items: center; justify-content: center; cursor: pointer;
  }

  .mode-pill-item { padding: 8px 10px; border-radius: 8px; cursor: pointer; transition: background 0.15s; }
  .mode-pill-item:hover { background: var(--inputBg); }
  .mode-pill-item-active { background: var(--accent-soft); }
  .mode-pill-item-title { font-size: 12.5px; color: var(--text); font-weight: 500; }
  .mode-pill-item-desc { font-size: 10.5px; color: var(--textFaint); margin-top: 1px; }
  .mode-expand-popup {
    position: absolute; bottom: calc(100% + 8px); left: 0;
    background: var(--surfaceRaised); border: 1px solid var(--borderStrong);
    border-radius: 12px; padding: 6px; width: 230px;
    box-shadow: 0 12px 32px -8px rgba(0,0,0,0.5); z-index: 30;
  }

  .mobile-composer-wrap { padding: 8px 8px 10px; }
  .mobile-composer { background: var(--surface); border: 1px solid var(--border); border-radius: 18px; padding: 12px 12px 8px; }
  .mobile-composer input { width: 100%; background: transparent; border: none; outline: none; color: var(--text); font-size: 14.5px; font-family: inherit; padding: 4px 4px 12px; }
  .mobile-composer input::placeholder { color: var(--textFainter); }
  .mobile-composer-row { display: flex; align-items: center; justify-content: space-between; }
  .mobile-composer-left { display: flex; align-items: center; gap: 6px; position: relative; }
  .attach-btn-mobile { position: relative; }
  .mobile-composer-right { display: flex; align-items: center; gap: 6px; }

  .mode-compact-wrap { position: relative; }
  .mode-compact-btn { display: flex; align-items: center; gap: 4px; height: 30px; padding: 0 9px; border-radius: 15px; border: 1px solid var(--border); background: var(--inputBg); color: var(--textMuted); cursor: pointer; }
  .mode-compact-popup {
    position: absolute; bottom: calc(100% + 8px); left: 0;
    background: var(--surfaceRaised); border: 1px solid var(--borderStrong);
    border-radius: 12px; padding: 8px; width: 230px;
    box-shadow: 0 12px 32px -8px rgba(0,0,0,0.5); z-index: 30;
    max-height: 60vh; overflow-y: auto;
  }
  .mode-compact-group { margin-bottom: 6px; }
  .mode-compact-group:last-child { margin-bottom: 0; }
  .mode-compact-group-label { font-size: 10px; color: var(--textFainter); text-transform: uppercase; letter-spacing: 0.05em; padding: 6px 8px 4px; }

  .panel-overlay { position: fixed; inset: 0; background: var(--overlay); z-index: 60; }
  .side-panel {
    position: fixed; top: 14px; left: 84px; bottom: 14px; width: 340px; max-width: calc(100vw - 100px);
    background: var(--surfaceAlt); border: 1px solid var(--border); border-radius: 18px;
    z-index: 70; display: flex; flex-direction: column;
    box-shadow: 0 24px 60px -20px rgba(0,0,0,0.6);
  }
  .side-panel-mobile { left: 8px; right: 8px; width: auto; max-width: none; }
  .side-panel-header { display: flex; align-items: center; justify-content: space-between; padding: 16px 18px; border-bottom: 1px solid var(--border); }
  .side-panel-header h2 { font-size: 15px; font-weight: 600; }
  .side-panel-body { flex: 1; overflow-y: auto; padding: 14px 16px; }

  .icon-btn-sm { background: transparent; border: none; color: var(--textFaint); cursor: pointer; padding: 5px; border-radius: 6px; display: flex; transition: background 0.15s, color 0.15s; }
  .icon-btn-sm:hover { background: var(--inputBg); color: var(--text); }

  .history-list { display: flex; flex-direction: column; gap: 2px; }
  .history-item { display: flex; align-items: flex-start; gap: 9px; padding: 9px 8px; border-radius: 9px; cursor: pointer; transition: background 0.15s; }
  .history-item:hover { background: var(--inputBg); }
  .history-item-title { font-size: 12.5px; color: var(--text); }
  .history-item-time { font-size: 11px; color: var(--textFainter); margin-top: 2px; }

  .panel-search-input { width: 100%; background: var(--inputBg); border: 1px solid var(--border); border-radius: 10px; padding: 10px 12px; color: var(--text); font-size: 13px; outline: none; }

  .explore-group { margin-bottom: 18px; }
  .explore-group-title { font-size: 12px; font-weight: 600; margin-bottom: 8px; text-transform: uppercase; letter-spacing: 0.04em; color: var(--accent); }
  .explore-item { padding: 9px 8px; border-radius: 9px; cursor: pointer; transition: background 0.15s; }
  .explore-item:hover { background: var(--inputBg); }
  .explore-item-title { font-size: 13px; color: var(--text); font-weight: 500; }
  .explore-item-desc { font-size: 11.5px; color: var(--textFaint); margin-top: 2px; }

  .apps-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; }
  .app-tile { background: var(--inputBg); border: 1px solid var(--border); border-radius: 12px; padding: 16px 12px; font-size: 12px; color: var(--text); cursor: pointer; transition: border-color 0.15s; text-align: center; }
  .app-tile:hover { border-color: var(--accent); }

  .panel-section { margin-bottom: 22px; }
  .panel-section-title { font-size: 11px; color: var(--textFainter); text-transform: uppercase; letter-spacing: 0.05em; margin-bottom: 8px; }
  .settings-row { display: flex; align-items: center; justify-content: space-between; padding: 12px 0; border-bottom: 1px solid var(--border); gap: 10px; }
  .settings-row-label { font-size: 13px; color: var(--text); }
  .settings-row-desc { font-size: 11.5px; color: var(--textFaint); margin-top: 2px; }

  .segmented { display: flex; background: var(--inputBg); border-radius: 8px; padding: 2px; flex-shrink: 0; }
  .segmented button { background: transparent; border: none; color: var(--textMuted); font-size: 12px; padding: 6px 11px; border-radius: 6px; cursor: pointer; }
  .seg-active { background: var(--surfaceRaised) !important; color: var(--text) !important; }

  .select { background: var(--inputBg); border: 1px solid var(--border); color: var(--text); border-radius: 8px; padding: 6px 9px; font-size: 12px; outline: none; }
  .chips { display: flex; gap: 5px; flex-wrap: wrap; }
  .chip { font-size: 11px; padding: 4px 9px; border-radius: 20px; background: var(--inputBg); color: var(--textFaint); border: 1px solid var(--border); }
  .chip-on { background: var(--accent-soft); color: var(--accent); border-color: var(--accent); }

  .accent-row { display: flex; gap: 8px; }
  .accent-swatch { width: 26px; height: 26px; border-radius: 50%; border: 2px solid transparent; cursor: pointer; transition: transform 0.15s, border-color 0.15s; }
  .accent-swatch:hover { transform: scale(1.08); }
  .accent-swatch-active { border-color: var(--text); }

  .switch { position: relative; width: 36px; height: 21px; display: inline-block; flex-shrink: 0; }
  .switch input { opacity: 0; width: 0; height: 0; }
  .switch-slider { position: absolute; inset: 0; background: var(--inputBg); border-radius: 20px; cursor: pointer; transition: 0.2s; }
  .switch-slider:before { content: ""; position: absolute; width: 15px; height: 15px; left: 3px; top: 3px; background: var(--textFaint); border-radius: 50%; transition: 0.2s; }
  .switch input:checked + .switch-slider { background: var(--accent-soft); }
  .switch input:checked + .switch-slider:before { transform: translateX(15px); background: var(--accent); }

  .btn-secondary { background: var(--inputBg); border: 1px solid var(--border); color: var(--text); padding: 6px 13px; border-radius: 8px; font-size: 12px; cursor: pointer; }
  .btn-primary-sm { background: var(--text); color: var(--bg); border: none; padding: 5px 12px; border-radius: 7px; font-size: 11.5px; font-weight: 600; cursor: pointer; }

  .profile-hero { display: flex; align-items: center; gap: 12px; margin-bottom: 22px; }
  .avatar-lg { width: 46px; height: 46px; border-radius: 13px; background: var(--accent); display: flex; align-items: center; justify-content: center; font-size: 18px; font-weight: 600; color: white; }
  .profile-hero-name { font-size: 15.5px; font-weight: 600; }
  .profile-hero-sub { font-size: 12px; color: var(--textFaint); margin-top: 2px; }

  .plan-card { background: var(--inputBg); border: 1px solid var(--border); border-radius: 12px; padding: 14px 16px; }
  .plan-card-top { display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px; }
  .plan-name { font-size: 13px; font-weight: 600; }
  .usage-row { display: flex; align-items: center; gap: 8px; font-size: 11.5px; color: var(--textMuted); margin-bottom: 7px; }
  .usage-row span:first-child { width: 90px; flex-shrink: 0; }
  .usage-bar { flex: 1; height: 5px; background: var(--border); border-radius: 4px; overflow: hidden; }
  .usage-fill { height: 100%; background: var(--accent); border-radius: 4px; }
  .usage-count { width: 45px; flex-shrink: 0; text-align: right; color: var(--textFaint); }

  .icon-11 { width: 11px; height: 11px; }
  .icon-14 { width: 14px; height: 14px; }
  .icon-15 { width: 15px; height: 15px; }
  .icon-16 { width: 16px; height: 16px; }
  .icon-18 { width: 18px; height: 18px; }

  @media (max-width: 767px) {
    .app { padding: 0; gap: 0; }
    .main-view { border-radius: 0; border: none; }
    .feature-cards { flex-direction: column; }
    .feature-card-title { min-height: 0; }
    .greeting h1 { font-size: 21px; }
    .greeting { margin-bottom: 22px; }
    .center-wrap { padding: 16px; }
    .mobile-composer-wrap { padding: 6px 8px 8px; }
    .mobile-drawer { width: 260px; padding: 14px; }
    .mode-compact-popup { left: -20px; }
    .results { padding: 12px 14px 6px; }
    .card { padding: 16px 16px; }
  }

  @media (max-width: 380px) {
    .greeting h1 { font-size: 18px; }
    .mobile-drawer { width: 88vw; }
  }
`;

export default function App() {
  return (
    <ThemeProvider>
      <AppShell />
    </ThemeProvider>
  );
}
