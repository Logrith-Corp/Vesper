import React, { useState, useRef, useEffect } from "react";

// ---------- Icons (inline SVG, no deps) ----------
const Icon = {
  plus: (p) => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" {...p}>
      <path d="M12 5v14M5 12h14" strokeLinecap="round" />
    </svg>
  ),
  history: (p) => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" {...p}>
      <path d="M3 12a9 9 0 1 0 3-6.7" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M3 4v5h5" strokeLinecap="round" strokeLinejoin="round" />
      <path d="M12 7v5l3 3" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  ),
  settings: (p) => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" {...p}>
      <circle cx="12" cy="12" r="3" />
      <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.6a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z" />
    </svg>
  ),
  user: (p) => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" {...p}>
      <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2" strokeLinecap="round" strokeLinejoin="round" />
      <circle cx="12" cy="7" r="4" />
    </svg>
  ),
  paperclip: (p) => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" {...p}>
      <path d="M21.44 11.05l-9.19 9.19a6 6 0 0 1-8.49-8.49l9.19-9.19a4 4 0 0 1 5.66 5.66l-9.2 9.19a2 2 0 0 1-2.83-2.83l8.49-8.48" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  ),
  image: (p) => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" {...p}>
      <rect x="3" y="3" width="18" height="18" rx="2" />
      <circle cx="8.5" cy="8.5" r="1.5" />
      <path d="M21 15l-5-5L5 21" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  ),
  camera: (p) => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" {...p}>
      <path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z" strokeLinecap="round" strokeLinejoin="round" />
      <circle cx="12" cy="13" r="4" />
    </svg>
  ),
  send: (p) => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" {...p}>
      <path d="M22 2L11 13M22 2l-7 20-4-9-9-4z" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  ),
  chevron: (p) => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" {...p}>
      <path d="M6 9l6 6 6-6" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  ),
  sparkle: (p) => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" {...p}>
      <path d="M12 3v4M12 17v4M3 12h4M17 12h4M5.6 5.6l2.8 2.8M15.6 15.6l2.8 2.8M18.4 5.6l-2.8 2.8M8.4 15.6l-2.8 2.8" strokeLinecap="round" />
    </svg>
  ),
  search: (p) => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" {...p}>
      <circle cx="11" cy="11" r="7" />
      <path d="M21 21l-4.35-4.35" strokeLinecap="round" />
    </svg>
  ),
  layers: (p) => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" {...p}>
      <path d="M12 2l9 5-9 5-9-5 9-5z" strokeLinejoin="round" />
      <path d="M3 12l9 5 9-5M3 17l9 5 9-5" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  ),
  map: (p) => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" {...p}>
      <path d="M9 20l-6-3V4l6 3 6-3 6 3v13l-6-3-6 3z" strokeLinejoin="round" />
      <path d="M9 7v13M15 4v13" />
    </svg>
  ),
  close: (p) => (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" {...p}>
      <path d="M18 6L6 18M6 6l12 12" strokeLinecap="round" />
    </svg>
  ),
};

// ---------- Mock data ----------
const HISTORY = [
  { id: 1, title: "Should I build an AI note-taking startup?", time: "2h ago", mode: "research" },
  { id: 2, title: "Next.js vs Svelte for solo-founder SaaS", time: "Yesterday", mode: "ask" },
  { id: 3, title: "Analyze Cursor pricing and moat", time: "Yesterday", mode: "plan" },
  { id: 4, title: "What do developers think about Bun?", time: "3 days ago", mode: "research" },
  { id: 5, title: "AI CRM market landscape 2026", time: "Last week", mode: "research" },
  { id: 6, title: "Founder community distribution strategy", time: "Last week", mode: "plan" },
];

const MODE_CONFIG = {
  ask: {
    label: "Ask",
    icon: Icon.sparkle,
    sub: [
      { key: "ask", label: "Ask", desc: "Quick answer, cheap & fast" },
      { key: "ask_thinking", label: "Ask + Thinking", desc: "Reasons before answering" },
    ],
  },
  research: {
    label: "Research",
    icon: Icon.search,
    sub: [
      { key: "research", label: "Research", desc: "Multi-source search & summary" },
      { key: "deep_research", label: "Deep Research + Thinking", desc: "Patterns, contradictions, insight" },
    ],
  },
  plan: {
    label: "Plan",
    icon: Icon.map,
    sub: [
      { key: "plan", label: "Plan", desc: "Straightforward action plan" },
      { key: "deep_plan", label: "Deep Plan + Thinking", desc: "Full strategy with tradeoffs" },
    ],
  },
};

function ModeDot({ mode }) {
  const colors = { ask: "#7C6FF0", research: "#4FD1C5", plan: "#F0B457" };
  return <span className="mode-dot" style={{ background: colors[mode] || "#7C6FF0" }} />;
}

function ModeSelector({ activeMain, activeSub, onSelect }) {
  const [openMain, setOpenMain] = useState(null);
  const wrapRef = useRef(null);

  useEffect(() => {
    function onClick(e) {
      if (wrapRef.current && !wrapRef.current.contains(e.target)) setOpenMain(null);
    }
    document.addEventListener("mousedown", onClick);
    return () => document.removeEventListener("mousedown", onClick);
  }, []);

  return (
    <div className="mode-selector" ref={wrapRef}>
      {Object.entries(MODE_CONFIG).map(([key, cfg]) => {
        const IconComp = cfg.icon;
        const isActiveMain = activeMain === key;
        return (
          <div className="mode-btn-wrap" key={key}>
            <button
              type="button"
              className={`mode-btn ${isActiveMain ? "mode-btn-active" : ""}`}
              onClick={() => setOpenMain(openMain === key ? null : key)}
            >
              <IconComp className="mode-btn-icon" />
              {cfg.label}
              <Icon.chevron className="mode-btn-chevron" />
            </button>
            {openMain === key && (
              <div className="mode-popup">
                {cfg.sub.map((s) => (
                  <div
                    key={s.key}
                    className={`mode-popup-item ${activeSub === s.key ? "mode-popup-item-active" : ""}`}
                    onClick={() => {
                      onSelect(key, s.key);
                      setOpenMain(null);
                    }}
                  >
                    <div className="mode-popup-item-title">{s.label}</div>
                    <div className="mode-popup-item-desc">{s.desc}</div>
                  </div>
                ))}
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}

function Sidebar({ collapsed, onNewResearch, activeView, setActiveView }) {
  return (
    <aside className={`sidebar ${collapsed ? "sidebar-collapsed" : ""}`}>
      <div className="sidebar-top">
        <div className="brand">
          <span className="brand-mark" />
          {!collapsed && <span className="brand-name">Research OS</span>}
        </div>
      </div>

      <button className="new-research-btn" onClick={onNewResearch}>
        <Icon.plus className="icon-16" />
        {!collapsed && <span>New Research</span>}
      </button>

      <div className="sidebar-section-label">{!collapsed && "History"}</div>
      <div className="history-list">
        {HISTORY.map((h) => (
          <div key={h.id} className="history-item" title={h.title}>
            <ModeDot mode={h.mode} />
            {!collapsed && (
              <div className="history-item-text">
                <div className="history-item-title">{h.title}</div>
                <div className="history-item-time">{h.time}</div>
              </div>
            )}
          </div>
        ))}
      </div>

      <div className="sidebar-bottom">
        <div
          className={`sidebar-bottom-item ${activeView === "settings" ? "sidebar-bottom-active" : ""}`}
          onClick={() => setActiveView("settings")}
        >
          <Icon.settings className="icon-18" />
          {!collapsed && <span>Settings</span>}
        </div>
        <div
          className={`sidebar-bottom-item ${activeView === "profile" ? "sidebar-bottom-active" : ""}`}
          onClick={() => setActiveView("profile")}
        >
          <div className="avatar-sm">L</div>
          {!collapsed && (
            <div className="profile-text">
              <div className="profile-name">Logosi</div>
              <div className="profile-plan">Free plan</div>
            </div>
          )}
        </div>
      </div>
    </aside>
  );
}

function SettingsPanel({ onClose }) {
  const [theme, setTheme] = useState("dark");
  const [defaultMode, setDefaultMode] = useState("research");

  return (
    <div className="panel">
      <div className="panel-header">
        <h2>Settings</h2>
        <button className="icon-btn" onClick={onClose}>
          <Icon.close className="icon-18" />
        </button>
      </div>

      <div className="panel-section">
        <div className="panel-section-title">Appearance</div>
        <div className="settings-row">
          <div>
            <div className="settings-row-label">Theme</div>
            <div className="settings-row-desc">Interface color mode</div>
          </div>
          <div className="segmented">
            <button className={theme === "dark" ? "seg-active" : ""} onClick={() => setTheme("dark")}>Dark</button>
            <button className={theme === "light" ? "seg-active" : ""} onClick={() => setTheme("light")}>Light</button>
          </div>
        </div>
      </div>

      <div className="panel-section">
        <div className="panel-section-title">Research defaults</div>
        <div className="settings-row">
          <div>
            <div className="settings-row-label">Default mode</div>
            <div className="settings-row-desc">Used when you start a new research</div>
          </div>
          <select className="select" value={defaultMode} onChange={(e) => setDefaultMode(e.target.value)}>
            <option value="ask">Ask</option>
            <option value="research">Research</option>
            <option value="plan">Plan</option>
          </select>
        </div>
        <div className="settings-row">
          <div>
            <div className="settings-row-label">Source preferences</div>
            <div className="settings-row-desc">Sources included by default in research mode</div>
          </div>
          <div className="chips">
            <span className="chip chip-on">Web</span>
            <span className="chip chip-on">Reddit</span>
            <span className="chip chip-on">GitHub</span>
            <span className="chip">News</span>
          </div>
        </div>
      </div>

      <div className="panel-section">
        <div className="panel-section-title">Notifications</div>
        <div className="settings-row">
          <div>
            <div className="settings-row-label">Email updates</div>
            <div className="settings-row-desc">Product updates and usage summaries</div>
          </div>
          <label className="switch">
            <input type="checkbox" defaultChecked />
            <span className="switch-slider" />
          </label>
        </div>
      </div>
    </div>
  );
}

function ProfilePanel({ onClose }) {
  return (
    <div className="panel">
      <div className="panel-header">
        <h2>Profile</h2>
        <button className="icon-btn" onClick={onClose}>
          <Icon.close className="icon-18" />
        </button>
      </div>

      <div className="profile-hero">
        <div className="avatar-lg">L</div>
        <div>
          <div className="profile-hero-name">Logosi</div>
          <div className="profile-hero-sub">Builder · Logrith</div>
        </div>
      </div>

      <div className="panel-section">
        <div className="panel-section-title">Account</div>
        <div className="settings-row">
          <div>
            <div className="settings-row-label">Email</div>
            <div className="settings-row-desc">logosi@logrith.in</div>
          </div>
          <button className="btn-secondary">Change</button>
        </div>
        <div className="settings-row">
          <div>
            <div className="settings-row-label">Password</div>
            <div className="settings-row-desc">Last changed 3 months ago</div>
          </div>
          <button className="btn-secondary">Update</button>
        </div>
      </div>

      <div className="panel-section">
        <div className="panel-section-title">Plan & usage</div>
        <div className="plan-card">
          <div className="plan-card-top">
            <span className="plan-name">Free Plan</span>
            <button className="btn-primary-sm">Upgrade</button>
          </div>
          <div className="usage-row">
            <span>Ask</span>
            <div className="usage-bar"><div className="usage-fill" style={{ width: "20%" }} /></div>
            <span className="usage-count">Unlimited</span>
          </div>
          <div className="usage-row">
            <span>Research</span>
            <div className="usage-bar"><div className="usage-fill" style={{ width: "60%" }} /></div>
            <span className="usage-count">6/10 today</span>
          </div>
          <div className="usage-row">
            <span>Deep Research</span>
            <div className="usage-bar"><div className="usage-fill" style={{ width: "0%" }} /></div>
            <span className="usage-count">0/2 today</span>
          </div>
        </div>
      </div>
    </div>
  );
}

const STAGES = [
  "Understanding intent",
  "Selecting sources",
  "Collecting data",
  "Finding patterns",
  "Generating insight",
];

const SAMPLE_REPORT = `## Summary
AI note-taking is a crowded space, but most incumbents optimize for consumers, not founders who need research-grade memory.

## Key Findings
- Notion, Obsidian, and Mem dominate mindshare but skew toward general productivity.
- Reddit complaints cluster around search quality and AI accuracy, not feature count.

## Patterns
- Every major complaint across sources is retrieval quality, not UI polish.
- Founders specifically want memory tied to decisions, not just notes.

## Contradictions
- Marketing pages claim "powerful AI search"; user reviews consistently rate search as the weakest feature.

## Opportunities
- A founder-only memory layer tied to research and decisions, not generic notes.

## Recommendation
Build a narrow wedge: memory linked to research sessions, not a general notes app.`;

function Report({ text }) {
  const lines = text.split("\n");
  return (
    <div className="report">
      {lines.map((line, i) => {
        if (line.startsWith("## ")) return <h2 key={i}>{line.replace("## ", "")}</h2>;
        if (line.trim().startsWith("- ")) return <li key={i}>{line.trim().replace(/^- /, "")}</li>;
        if (line.trim() === "") return <div key={i} className="spacer" />;
        return <p key={i}>{line}</p>;
      })}
    </div>
  );
}

function MainView({ mainMode, subMode, onModeSelect, query, setQuery }) {
  const [loading, setLoading] = useState(false);
  const [stageIdx, setStageIdx] = useState(0);
  const [result, setResult] = useState(null);
  const timerRef = useRef(null);

  function handleSend() {
    if (!query.trim() || loading) return;
    setResult(null);
    setLoading(true);
    setStageIdx(0);

    let i = 0;
    timerRef.current = setInterval(() => {
      i += 1;
      setStageIdx(i);
      if (i >= STAGES.length - 1) {
        clearInterval(timerRef.current);
        setTimeout(() => {
          setLoading(false);
          setResult({ mode: subMode, report: SAMPLE_REPORT });
        }, 600);
      }
    }, 450);
  }

  useEffect(() => () => clearInterval(timerRef.current), []);

  const hasContent = loading || result;

  return (
    <div className="main-view">
      {!hasContent && (
        <div className="hero">
          <div className="eyebrow">Information + Insight + Action</div>
          <h1>Research that thinks,<br />not just searches.</h1>
          <p>Built for founders and developers.</p>
        </div>
      )}

      {hasContent && (
        <div className="results">
          {loading && (
            <div className="trace">
              {STAGES.map((s, i) => {
                const state = i < stageIdx ? "done" : i === stageIdx ? "active" : "pending";
                return (
                  <div key={s} className={`trace-row trace-${state}`}>
                    <span className="trace-marker">{state === "done" ? "✓" : ""}</span>
                    <span>{s}</span>
                  </div>
                );
              })}
            </div>
          )}
          {result && (
            <div className="card">
              <div className="tags">
                <span className="tag tag-mode"><ModeDot mode={mainMode} />{MODE_CONFIG[mainMode]?.sub.find(s => s.key === subMode)?.label || subMode}</span>
                <span className="tag tag-source">web</span>
                <span className="tag tag-source">reddit</span>
                <span className="tag tag-source">github</span>
              </div>
              <Report text={result.report} />
            </div>
          )}
        </div>
      )}

      <div className="composer-wrap">
        <div className="composer">
          <div className="composer-icons">
            <button className="icon-btn" title="Attach file"><Icon.paperclip className="icon-18" /></button>
            <button className="icon-btn" title="Attach image"><Icon.image className="icon-18" /></button>
            <button className="icon-btn" title="Camera"><Icon.camera className="icon-18" /></button>
          </div>
          <textarea
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Ask a research question..."
            rows={1}
            onKeyDown={(e) => {
              if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                handleSend();
              }
            }}
          />
          <button className="send-btn" onClick={handleSend} disabled={loading}>
            <Icon.send className="icon-16" />
          </button>
        </div>
        <ModeSelector activeMain={mainMode} activeSub={subMode} onSelect={onModeSelect} />
      </div>
    </div>
  );
}

export default function App() {
  const [collapsed, setCollapsed] = useState(false);
  const [activeView, setActiveView] = useState("main");
  const [mainMode, setMainMode] = useState("research");
  const [subMode, setSubMode] = useState("research");
  const [query, setQuery] = useState("");

  function handleModeSelect(main, sub) {
    setMainMode(main);
    setSubMode(sub);
  }

  function handleNewResearch() {
    setActiveView("main");
    setQuery("");
  }

  return (
    <div className="app">
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500&display=swap');
        * { box-sizing: border-box; margin: 0; padding: 0; }
        .app {
          display: flex;
          height: 100vh;
          width: 100%;
          background: #0A0A0D;
          color: #E4E4E9;
          font-family: 'Inter', -apple-system, sans-serif;
          overflow: hidden;
        }

        /* ---------- Sidebar ---------- */
        .sidebar {
          width: 248px;
          flex-shrink: 0;
          background: #0D0D11;
          border-right: 1px solid rgba(255,255,255,0.06);
          display: flex;
          flex-direction: column;
          padding: 14px 10px;
          transition: width 0.2s;
        }
        .sidebar-collapsed { width: 68px; }
        .sidebar-top { padding: 6px 8px 16px; }
        .brand { display: flex; align-items: center; gap: 8px; }
        .brand-mark {
          width: 20px; height: 20px; border-radius: 6px; flex-shrink: 0;
          background: linear-gradient(135deg, #6E6E76, #3A3A40);
        }
        .brand-name { font-size: 14px; font-weight: 600; letter-spacing: -0.01em; }

        .new-research-btn {
          display: flex; align-items: center; gap: 8px;
          background: #17171C; border: 1px solid rgba(255,255,255,0.08);
          color: #E4E4E9; border-radius: 9px; padding: 9px 12px;
          font-size: 13px; font-weight: 500; cursor: pointer;
          margin-bottom: 18px; transition: background 0.15s, border-color 0.15s;
        }
        .new-research-btn:hover { background: #1D1D23; border-color: rgba(255,255,255,0.14); }

        .sidebar-section-label {
          font-size: 11px; color: #55555F; text-transform: uppercase;
          letter-spacing: 0.06em; padding: 4px 8px 8px;
        }
        .history-list { flex: 1; overflow-y: auto; display: flex; flex-direction: column; gap: 2px; }
        .history-item {
          display: flex; align-items: flex-start; gap: 9px;
          padding: 8px; border-radius: 8px; cursor: pointer;
          transition: background 0.15s;
        }
        .history-item:hover { background: #17171C; }
        .mode-dot { width: 6px; height: 6px; border-radius: 50%; margin-top: 6px; flex-shrink: 0; }
        .history-item-text { min-width: 0; }
        .history-item-title {
          font-size: 12.5px; color: #C4C4CE; white-space: nowrap;
          overflow: hidden; text-overflow: ellipsis;
        }
        .history-item-time { font-size: 11px; color: #55555F; margin-top: 2px; }

        .sidebar-bottom { border-top: 1px solid rgba(255,255,255,0.06); padding-top: 10px; margin-top: 8px; }
        .sidebar-bottom-item {
          display: flex; align-items: center; gap: 10px;
          padding: 8px; border-radius: 8px; cursor: pointer;
          color: #9494A6; font-size: 13px; transition: background 0.15s, color 0.15s;
        }
        .sidebar-bottom-item:hover { background: #17171C; color: #E4E4E9; }
        .sidebar-bottom-active { background: #17171C; color: #E4E4E9; }
        .avatar-sm {
          width: 22px; height: 22px; border-radius: 6px; background: #2A2A32;
          display: flex; align-items: center; justify-content: center;
          font-size: 11px; font-weight: 600; color: #C4C4CE; flex-shrink: 0;
        }
        .profile-text { min-width: 0; }
        .profile-name { font-size: 12.5px; color: #E4E4E9; }
        .profile-plan { font-size: 11px; color: #55555F; }

        /* ---------- Main view ---------- */
        .main-view {
          flex: 1; display: flex; flex-direction: column;
          overflow: hidden; position: relative;
        }
        .hero {
          flex: 1; display: flex; flex-direction: column;
          align-items: center; justify-content: center; text-align: center;
          padding: 24px;
        }
        .eyebrow {
          font-family: 'JetBrains Mono', monospace; font-size: 11px;
          letter-spacing: 0.08em; text-transform: uppercase;
          color: #6E6E9A; margin-bottom: 14px;
        }
        .hero h1 {
          font-size: 32px; font-weight: 600; letter-spacing: -0.03em;
          line-height: 1.2; margin-bottom: 10px; color: #F0F0F4;
        }
        .hero p { color: #7A7A88; font-size: 14.5px; }

        .results { flex: 1; overflow-y: auto; padding: 24px 24px 12px; max-width: 720px; margin: 0 auto; width: 100%; }

        .trace {
          background: #111116; border: 1px solid rgba(255,255,255,0.06);
          border-radius: 12px; padding: 16px 18px; margin-bottom: 16px;
        }
        .trace-row {
          display: flex; align-items: center; gap: 10px; padding: 6px 0;
          font-size: 13px; color: #45454F; transition: color 0.3s;
        }
        .trace-row.trace-active { color: #E4E4E9; }
        .trace-row.trace-done { color: #6E6E9A; }
        .trace-marker {
          width: 15px; height: 15px; border-radius: 50%; border: 1.5px solid #2A2A32;
          display: flex; align-items: center; justify-content: center;
          font-size: 9px; flex-shrink: 0;
        }
        .trace-done .trace-marker { border-color: #6E6E9A; background: rgba(110,110,154,0.15); }
        .trace-active .trace-marker { border-color: #6E6E9A; background: #6E6E9A; animation: pulse 1s infinite; }
        @keyframes pulse {
          0%, 100% { box-shadow: 0 0 0 0 rgba(110,110,154,0.4); }
          50% { box-shadow: 0 0 0 5px rgba(110,110,154,0); }
        }

        .card { background: #111116; border: 1px solid rgba(255,255,255,0.06); border-radius: 14px; padding: 22px 24px; }
        .tags { display: flex; gap: 6px; flex-wrap: wrap; margin-bottom: 16px; }
        .tag {
          font-family: 'JetBrains Mono', monospace; font-size: 11px; padding: 4px 10px;
          border-radius: 6px; display: inline-flex; align-items: center; gap: 5px;
        }
        .tag-mode { background: rgba(110,110,154,0.16); color: #B4B4E0; }
        .tag-source { background: rgba(255,255,255,0.05); color: #7A7A88; }

        .report h2 { font-size: 14.5px; font-weight: 600; color: #C4C4EE; margin: 18px 0 8px; }
        .report h2:first-child { margin-top: 0; }
        .report p, .report li { font-size: 13.5px; line-height: 1.65; color: #A8A8B4; margin-bottom: 4px; }
        .report li { margin-left: 18px; }
        .spacer { height: 2px; }

        /* ---------- Composer ---------- */
        .composer-wrap { padding: 12px 24px 20px; max-width: 720px; margin: 0 auto; width: 100%; }
        .composer {
          display: flex; align-items: flex-end; gap: 6px;
          background: #131318; border: 1px solid rgba(255,255,255,0.09);
          border-radius: 16px; padding: 10px 10px 10px 8px;
          transition: border-color 0.15s;
        }
        .composer:focus-within { border-color: rgba(255,255,255,0.2); }
        .composer-icons { display: flex; gap: 2px; padding-bottom: 2px; }
        .composer textarea {
          flex: 1; background: transparent; border: none; outline: none;
          color: #E4E4E9; font-size: 14px; font-family: inherit;
          resize: none; padding: 8px 6px; max-height: 140px; line-height: 1.4;
        }
        .composer textarea::placeholder { color: #55555F; }
        .send-btn {
          width: 32px; height: 32px; border-radius: 9px; border: none;
          background: #E4E4E9; color: #0A0A0D; display: flex;
          align-items: center; justify-content: center; cursor: pointer;
          flex-shrink: 0; transition: opacity 0.15s;
        }
        .send-btn:disabled { opacity: 0.3; cursor: default; }

        /* ---------- Mode selector ---------- */
        .mode-selector { display: flex; gap: 6px; margin-top: 8px; }
        .mode-btn-wrap { position: relative; }
        .mode-btn {
          display: flex; align-items: center; gap: 6px;
          background: transparent; border: 1px solid rgba(255,255,255,0.08);
          color: #8A8A96; padding: 6px 10px; border-radius: 8px;
          font-size: 12.5px; cursor: pointer; transition: all 0.15s;
        }
        .mode-btn:hover { background: rgba(255,255,255,0.04); color: #E4E4E9; }
        .mode-btn-active { background: rgba(110,110,154,0.14); border-color: rgba(110,110,154,0.4); color: #C4C4EE; }
        .mode-btn-icon { width: 13px; height: 13px; }
        .mode-btn-chevron { width: 11px; height: 11px; opacity: 0.6; }

        .mode-popup {
          position: absolute; bottom: calc(100% + 8px); left: 0;
          background: #16161C; border: 1px solid rgba(255,255,255,0.1);
          border-radius: 10px; padding: 6px; width: 220px;
          box-shadow: 0 12px 32px -8px rgba(0,0,0,0.6); z-index: 10;
        }
        .mode-popup-item { padding: 8px 10px; border-radius: 7px; cursor: pointer; transition: background 0.15s; }
        .mode-popup-item:hover { background: rgba(255,255,255,0.05); }
        .mode-popup-item-active { background: rgba(110,110,154,0.14); }
        .mode-popup-item-title { font-size: 12.5px; color: #E4E4E9; font-weight: 500; }
        .mode-popup-item-desc { font-size: 11px; color: #6E6E78; margin-top: 1px; }

        /* ---------- Panels (Settings/Profile) ---------- */
        .panel { flex: 1; overflow-y: auto; padding: 32px 40px; max-width: 640px; }
        .panel-header { display: flex; align-items: center; justify-content: space-between; margin-bottom: 24px; }
        .panel-header h2 { font-size: 20px; font-weight: 600; }
        .icon-btn {
          background: transparent; border: none; color: #8A8A96; cursor: pointer;
          padding: 6px; border-radius: 7px; display: flex; transition: background 0.15s;
        }
        .icon-btn:hover { background: rgba(255,255,255,0.06); color: #E4E4E9; }

        .panel-section { margin-bottom: 28px; }
        .panel-section-title {
          font-size: 12px; color: #55555F; text-transform: uppercase;
          letter-spacing: 0.05em; margin-bottom: 10px;
        }
        .settings-row {
          display: flex; align-items: center; justify-content: space-between;
          padding: 14px 0; border-bottom: 1px solid rgba(255,255,255,0.05);
        }
        .settings-row-label { font-size: 13.5px; color: #E4E4E9; }
        .settings-row-desc { font-size: 12px; color: #6E6E78; margin-top: 2px; }

        .segmented { display: flex; background: #17171C; border-radius: 8px; padding: 2px; }
        .segmented button {
          background: transparent; border: none; color: #7A7A88; font-size: 12.5px;
          padding: 6px 12px; border-radius: 6px; cursor: pointer;
        }
        .seg-active { background: #26262E !important; color: #E4E4E9 !important; }

        .select {
          background: #17171C; border: 1px solid rgba(255,255,255,0.08); color: #E4E4E9;
          border-radius: 8px; padding: 7px 10px; font-size: 12.5px; outline: none;
        }
        .chips { display: flex; gap: 6px; }
        .chip {
          font-size: 11.5px; padding: 5px 10px; border-radius: 20px;
          background: #17171C; color: #6E6E78; border: 1px solid rgba(255,255,255,0.06);
        }
        .chip-on { background: rgba(110,110,154,0.16); color: #C4C4EE; border-color: rgba(110,110,154,0.3); }

        .switch { position: relative; width: 38px; height: 22px; display: inline-block; }
        .switch input { opacity: 0; width: 0; height: 0; }
        .switch-slider {
          position: absolute; inset: 0; background: #26262E; border-radius: 20px;
          cursor: pointer; transition: 0.2s;
        }
        .switch-slider:before {
          content: ""; position: absolute; width: 16px; height: 16px; left: 3px; top: 3px;
          background: #8A8A96; border-radius: 50%; transition: 0.2s;
        }
        .switch input:checked + .switch-slider { background: rgba(110,110,154,0.5); }
        .switch input:checked + .switch-slider:before { transform: translateX(16px); background: #C4C4EE; }

        .btn-secondary {
          background: #17171C; border: 1px solid rgba(255,255,255,0.08); color: #C4C4CE;
          padding: 7px 14px; border-radius: 8px; font-size: 12.5px; cursor: pointer;
        }
        .btn-secondary:hover { background: #1D1D23; }
        .btn-primary-sm {
          background: #E4E4E9; color: #0A0A0D; border: none;
          padding: 6px 14px; border-radius: 7px; font-size: 12px; font-weight: 600; cursor: pointer;
        }

        .profile-hero { display: flex; align-items: center; gap: 14px; margin-bottom: 28px; }
        .avatar-lg {
          width: 52px; height: 52px; border-radius: 14px; background: #26262E;
          display: flex; align-items: center; justify-content: center;
          font-size: 20px; font-weight: 600; color: #E4E4E9;
        }
        .profile-hero-name { font-size: 17px; font-weight: 600; }
        .profile-hero-sub { font-size: 12.5px; color: #6E6E78; margin-top: 2px; }

        .plan-card { background: #111116; border: 1px solid rgba(255,255,255,0.06); border-radius: 12px; padding: 16px 18px; }
        .plan-card-top { display: flex; justify-content: space-between; align-items: center; margin-bottom: 14px; }
        .plan-name { font-size: 13.5px; font-weight: 600; }
        .usage-row { display: flex; align-items: center; gap: 10px; font-size: 12px; color: #8A8A96; margin-bottom: 8px; }
        .usage-row span:first-child { width: 90px; flex-shrink: 0; }
        .usage-bar { flex: 1; height: 5px; background: #1D1D23; border-radius: 4px; overflow: hidden; }
        .usage-fill { height: 100%; background: #6E6E9A; border-radius: 4px; }
        .usage-count { width: 80px; flex-shrink: 0; text-align: right; color: #6E6E78; }
      `}</style>

      <Sidebar
        collapsed={collapsed}
        onNewResearch={handleNewResearch}
        activeView={activeView}
        setActiveView={setActiveView}
      />

      {activeView === "main" && (
        <MainView
          mainMode={mainMode}
          subMode={subMode}
          onModeSelect={handleModeSelect}
          query={query}
          setQuery={setQuery}
        />
      )}
      {activeView === "settings" && <SettingsPanel onClose={() => setActiveView("main")} />}
      {activeView === "profile" && <ProfilePanel onClose={() => setActiveView("main")} />}
    </div>
  );
}
