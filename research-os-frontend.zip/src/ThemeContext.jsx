import React, { createContext, useContext, useState, useEffect } from "react";

const ACCENT_OPTIONS = {
  violet: { name: "Violet", value: "#8B7CFF", soft: "rgba(139,124,255,0.16)" },
  teal: { name: "Teal", value: "#4FD1C5", soft: "rgba(79,209,197,0.16)" },
  amber: { name: "Amber", value: "#F0B457", soft: "rgba(240,180,87,0.16)" },
  rose: { name: "Rose", value: "#F0709A", soft: "rgba(240,112,154,0.16)" },
};

const THEMES = {
  dark: {
    bg: "#08080B",
    bgGradientA: "rgba(139,124,255,0.10)",
    bgGradientB: "rgba(79,209,197,0.06)",
    surface: "#131318",
    surfaceAlt: "#0C0C10",
    surfaceRaised: "#1A1A21",
    border: "rgba(255,255,255,0.07)",
    borderStrong: "rgba(255,255,255,0.14)",
    text: "#E4E4E9",
    textMuted: "#9494A6",
    textFaint: "#63636D",
    textFainter: "#4E4E58",
    inputBg: "rgba(255,255,255,0.05)",
    overlay: "rgba(0,0,0,0.45)",
  },
  light: {
    bg: "#F3F1FB",
    bgGradientA: "rgba(139,124,255,0.14)",
    bgGradientB: "rgba(79,209,197,0.08)",
    surface: "#FFFFFF",
    surfaceAlt: "#FBFAFE",
    surfaceRaised: "#FFFFFF",
    border: "rgba(20,20,40,0.08)",
    borderStrong: "rgba(20,20,40,0.16)",
    text: "#1A1A24",
    textMuted: "#63636F",
    textFaint: "#8A8A96",
    textFainter: "#A4A4B0",
    inputBg: "rgba(20,20,40,0.04)",
    overlay: "rgba(20,20,40,0.25)",
  },
};

const ThemeContext = createContext(null);

export function ThemeProvider({ children }) {
  const [mode, setMode] = useState("dark");
  const [accentKey, setAccentKey] = useState("violet");

  const theme = THEMES[mode];
  const accent = ACCENT_OPTIONS[accentKey];

  useEffect(() => {
    const root = document.documentElement;
    Object.entries(theme).forEach(([k, v]) => {
      root.style.setProperty(`--${k}`, v);
    });
    root.style.setProperty("--accent", accent.value);
    root.style.setProperty("--accent-soft", accent.soft);
  }, [theme, accent]);

  return (
    <ThemeContext.Provider value={{ mode, setMode, accentKey, setAccentKey, accent, ACCENT_OPTIONS }}>
      {children}
    </ThemeContext.Provider>
  );
}

export function useTheme() {
  return useContext(ThemeContext);
}

export { ACCENT_OPTIONS };
