# Research OS — Frontend Only (Zero Backend)

Pura UI: Sidebar (New Research, History, Settings, Profile) + Main composer (Ask/Research/Plan mode selector) + Settings + Profile panels. Sab kuch static/mock data hai — koi backend, koi API call nahi.

## Run karne ke liye

```
npm install
npm run dev
```

Browser mein `http://localhost:5173` khol lo.

## Structure

- `src/App.jsx` — poora app, ek hi file mein (sidebar + main view + settings + profile + mode selector). Styles bhi isi file ke andar `<style>` tag mein hain, koi Tailwind/external CSS nahi lagi.
- `src/main.jsx` — React entry point.

## Next steps (jab frontend finalize ho jaye)

- Backend wire karna: `/api/research` route (Gemini + Serper + Reddit + GitHub) — pehle ka discussed plan.
- Mock history/settings/profile data ko real state/DB se replace karna.
