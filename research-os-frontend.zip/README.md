# Research OS — Frontend Only (Zero Backend)

Pura UI: Sidebar (New Research, History, Settings, Profile) + Main composer (Ask/Research/Plan mode selector) + Settings + Profile panels. Sab kuch static/mock data hai — koi backend, koi API call nahi.

## Run karne ke liye

```
npm install
npm run dev
```

Browser mein `http://localhost:5173` khol lo.

## Structure

- `src/App.jsx` — poora app: desktop sidebar (slim ↔ expanded toggle), mobile hamburger drawer, Perplexity-style mobile composer, desktop composer with mode pills, side panels (History/Explore/Micro-tools/Settings/Profile).
- `src/ThemeContext.jsx` — real functional theme system. Dark/Light mode aur 4 accent colors (Violet/Teal/Amber/Rose) CSS variables ke through poori app mein apply hote hain — Settings panel se change karo, turant har jagah dikhega.
- `src/main.jsx` — React entry point.

## Responsive behavior

- **Desktop (≥768px):** Slim icon sidebar (56px) jo "panel expand" icon click karke wide (220px, labels ke saath) ho sakta hai. Composer bottom mein wide card, pill buttons (Ask/Research/Plan) ke saath.
- **Mobile (<768px):** Top header (hamburger + logo + avatar). Hamburger click → left drawer slides in (History/Explore/Apps/Settings + New Research). Bottom composer simple/compact (Perplexity jaisa) — mode selector ek chhota dropdown ban jata hai input row ke andar.

## Theme system

Settings panel mein jao → Appearance section → Dark/Light toggle aur accent color swatches. Yeh sab real-time CSS variables update karte hain (`--bg`, `--text`, `--accent`, etc.) — koi bhi reload/refresh nahi chahiye, turant change dikhega.

## Next steps (jab frontend finalize ho jaye)

- Backend wire karna: `/api/research` route (Gemini + Serper + Reddit + GitHub) — pehle ka discussed plan.
- Mock history/settings/profile data ko real state/DB se replace karna.
